using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using confighub.bridge.service.core.services;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.http;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.processors;
using confighub.bridge.infrastructure.repositories;
using confighub.bridge.infrastructure.services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using Serilog.Templates;
using System;
using System.IO;
using confighub.bridge.infrastructure.wrappers;
using integration.services.kafka.shared.interfaces;
using integration.services.kafka.shared.consumer;

namespace confighub.bridge.service
{
    public class Program
    {
        private const string Env = "ENV";

        public static void Main(string[] args)
        {
            CreateHostBuilder(args).UseSerilog().Build().Run();

            AppDomain.CurrentDomain.ProcessExit += (s, e) => Log.CloseAndFlush();

        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((hostingContext, configuration) =>
                {
                    string env = Environment.GetEnvironmentVariable(Env);
                    configuration.Sources.Clear();
                    configuration
                        .SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile($"appsettings.{env!.ToUpper()}.json", false, true)
                        .AddEnvironmentVariables();
                    var builder = configuration.Build();
                    var loggingLevel = builder["SeriLog:MinimumLevel:Default"];

                    var levelSwitch = new LoggingLevelSwitch();
                    levelSwitch.MinimumLevel = String.IsNullOrEmpty(loggingLevel) ?
                                                LogEventLevel.Information :
                                                (LogEventLevel)Enum.Parse(typeof(LogEventLevel), loggingLevel);

                    Log.Logger = new LoggerConfiguration()
                                .ReadFrom.Configuration(builder)
                                .MinimumLevel.ControlledBy(levelSwitch)
                                .Enrich.FromLogContext()
                                .Enrich.WithThreadId()
                                .WriteTo.Console(new ExpressionTemplate(
                                    "{ {..@p , @l: if @l = 'Information' then undefined() else @l,@m,@x,@sc: SourceContext, @t:UtcDateTime(@t),  SourceContext: undefined()} }\n"))
                                .WriteTo.File(@"Logs/" + GetLogFileName())
                                .CreateLogger();

                }).ConfigureServices((hostContext, services) =>
                {
                    services
                        .Configure<ConsumerConnectionOptions>(
                            hostContext.Configuration.GetSection(nameof(ConsumerConnectionOptions)))
                        .Configure<TtcConfigAuthOption>(
                            hostContext.Configuration.GetSection(nameof(TtcConfigAuthOption)))
                        .AddHttpClient()
                        // Hosted Service
                        .AddHostedService<InboundService>()
                        .AddHostedService<QueuedHostedService>()
                        // Background Task
                        .AddSingleton<IBackgroundTaskQueue<object>>(
                            new BackgroundTaskQueue<object>(
                                    hostContext.Configuration.GetValue<int>("BackgroundQueueCount")))
                        .AddSingleton<IHttpTransientFaultHandler, HttpTransientFaultHandler>()
                        .AddTransient<IIntegrationConfigurationService, IntegrationConfigurationService>()
                        .AddTransient<IConsumerClientWrapper, ConsumerClientWrapper>()
                        .AddScoped<IInboundProcessor, InboundProcessor>()
                        .AddTransient<IMessage, Message>()
                        .AddTransient<IAuthTokenService, AuthTokenService>()
                        .AddTransient<ICodeKeyService, CodeKeyService>()
                        .AddTransient<ICodeKeyValueService, CodeKeyValueService>()
                        .AddTransient<ICodeKeyLogService, CodeKeyLogService>()
                        .AddTransient<ITopicConnectionOptions, ConsumerConnectionOptions>()
                        .AddTransient<IConsumer, Consumer>()
                        .Configure<MongoDbSettings>(hostContext.Configuration.GetSection("DatabaseSettings"))
                        .AddSingleton<IMongoDbSettings, MongoDbSettings>(serviceProvider => serviceProvider.GetRequiredService<IOptions<MongoDbSettings>>().Value)
                        .AddSingleton<IMaintenanceDBContext, MaintenanceDBContext>()
                        .AddSingleton<ICloudHubDBContext, CloudHubDBContext>()
                        .AddScoped(typeof(IDataRepository<>), typeof(DataRepository<>))
                        .AddSingleton(AutoMapperConfiguration.Configure())
                        .AddTransient<IHttpService, HttpService>()
                        .AddTransient<ITokenService, TokenService>()
                        .AddTransient<IUnitOfService, UnitOfService>();
                });


        // This is a temporary code, should remove after mongo timeout issue resolved
        private static string GetLogFileName()
        {
            return string.Concat(
                  Path.GetFileNameWithoutExtension("app-"),
                  DateTime.UtcNow.ToString("yyyy-MM-dd-HH-mm-ss-fff"), ".log");
        }
    }
}

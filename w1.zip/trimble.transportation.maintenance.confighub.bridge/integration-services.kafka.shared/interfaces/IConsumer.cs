﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace integration.services.kafka.shared.interfaces
{
    public interface IConsumer
    {
        Task SubscribeAsync(string topic, Func<object, CancellationToken, Task> message, CancellationToken cancellationToken);
    }
}

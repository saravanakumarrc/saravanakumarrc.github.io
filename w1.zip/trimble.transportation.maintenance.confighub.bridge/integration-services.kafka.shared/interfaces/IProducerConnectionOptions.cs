﻿namespace integration.services.kafka.shared.interfaces
{
    public interface IProducerConnectionOptions
    {
        public string Host { get; set; }
        public int Port { get; set; }     
        public string Username { get; set; }
        public string Key { get; set; }

    }
}

﻿namespace iintegration.services.kafka.shared.interfaces
{
    public interface IConsumerConnectionOptions
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string Username { get; set; }
        public string Key { get; set; }
        public string InboundSubscription { get; set; }
    }
}

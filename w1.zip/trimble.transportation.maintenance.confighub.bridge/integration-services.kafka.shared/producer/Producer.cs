﻿using System;
using System.Threading.Tasks;
using integration.services.kafka.shared.interfaces;
using integration.services.kafka.shared.converters;
using Confluent.Kafka;
using CloudNative.CloudEvents.Kafka;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.NewtonsoftJson;
using Newtonsoft.Json;

namespace integration.services.kafka.shared.producer
{
    public class Producer: IProducer
    {        
        private ProducerConfig _producerConfig;
        private ProducerBuilder<string?, byte[]> _producerBuilder;
        private IProducer<string?, byte[]> _producer;

        public Producer(ITopicConnectionOptions producerTopicConnectionOptions)
        {
            _producerConfig = new ProducerConfig
            {
                BootstrapServers = producerTopicConnectionOptions.Host,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = producerTopicConnectionOptions.Username,
                SaslPassword = producerTopicConnectionOptions.Key,
            };            
        }

        // Used only for testing 
        public Producer(ITopicConnectionOptions producerTopicConnectionOptions, ProducerBuilder<string?, byte[]> producerBuilder, IProducer<string?, byte[]> producer)
        {
            _producerConfig = new ProducerConfig
            {
                BootstrapServers = producerTopicConnectionOptions.Host,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = producerTopicConnectionOptions.Username,
                SaslPassword = producerTopicConnectionOptions.Key,
            };

            _producerBuilder = producerBuilder;
            _producer = producer;
        }

        public async virtual Task<DeliveryResult<string?, byte[]>> PublishAsync(string topic, object message)
        {
            var eventMessageHandler = new EventMessageConverter();
            var kafkaMessage =  eventMessageHandler.CreateMessage<CloudEvent>(message).ToKafkaMessage(ContentMode.Binary, new JsonEventFormatter());
            _producerBuilder ??= new ProducerBuilder<string?, byte[]>(_producerConfig);

            using (_producer ??= _producerBuilder.Build())
            {
                try
                {
                    DeliveryResult<string?, byte[]> deliveryDetails = await _producer.ProduceAsync(topic, kafkaMessage);
                    return deliveryDetails;
                }
                catch (ProduceException<string, string> e)
                {
                    throw new Exception($"failed to deliver message: {e.Message} [{e.Error.Code}]");                    
                }
            }
        }
    }
}

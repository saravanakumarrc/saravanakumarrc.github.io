﻿using System;
using System.Threading;
using System.Threading.Tasks;
using integration.services.kafka.shared.interfaces;
using integration.services.kafka.shared.converters;
using Confluent.Kafka;
using Newtonsoft.Json;
using CloudNative.CloudEvents.NewtonsoftJson;
using Microsoft.Extensions.Logging;

namespace integration.services.kafka.shared.consumer
{
    public class Consumer : IConsumer
    {
        private ConsumerConfig _consumerConfig;
        private ConsumerBuilder<string?, byte[]> _consumerBuilder;
        private IConsumer<string?, byte[]> _consumer;
        private readonly ILogger<IConsumer> _logger;
        public Consumer(ITopicConnectionOptions consumerTopicConnectionOptions, ILogger<IConsumer> logger)
        {
            _consumerConfig = new ConsumerConfig
            {
                BootstrapServers = consumerTopicConnectionOptions.Host,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = consumerTopicConnectionOptions.Username,
                SaslPassword = consumerTopicConnectionOptions.Key,
                GroupId = consumerTopicConnectionOptions.InboundSubscription
            };

            _logger = logger;
        }
        public Consumer(ITopicConnectionOptions consumerTopicConnectionOptions, ConsumerBuilder<string?, byte[]> consumerBuilder, IConsumer<string?, byte[]> consumer)
        {
            _consumerConfig = new ConsumerConfig
            {
                BootstrapServers = consumerTopicConnectionOptions.Host,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = consumerTopicConnectionOptions.Username,
                SaslPassword = consumerTopicConnectionOptions.Key,
                GroupId = consumerTopicConnectionOptions.InboundSubscription
            };
            _consumerBuilder = consumerBuilder;
            _consumer = consumer;
        }

        public virtual Task SubscribeAsync(string topic, Func<object, CancellationToken, Task> message, CancellationToken stoppingToken)
        {
            var eventMessageHandler = new EventMessageConverter();
            _consumerBuilder ??= new ConsumerBuilder<string?, byte[]>(_consumerConfig);

            Task.Run(() =>
            {
                using (_consumer ??= _consumerBuilder.Build())
                {
                    _consumer.Subscribe(topic);
                    try
                    {
                        while (!stoppingToken.IsCancellationRequested)
                            try
                            {
                                var read = _consumer.Consume(stoppingToken);

                                if (read != null && read.Message != null && read.Message.Value != null)
                                {
                                    var receivedCloudEvent = eventMessageHandler.ToCloudEvent(read.Message, new JsonEventFormatter());
                                    message(receivedCloudEvent, stoppingToken);
                                }
                            }
                            catch (ConsumeException ex)
                            {
                                _logger.LogError($"Consume error: {ex.Error.Reason}");
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError($"Consume error: {ex.Message}");
                            }
                    }
                    catch (OperationCanceledException ex)
                    {
                        _logger.LogError($"Consumer is closed :{ex.Message}");
                        _consumer.Close();
                    }
                }
            });

            return Task.CompletedTask;
        }

    }
}

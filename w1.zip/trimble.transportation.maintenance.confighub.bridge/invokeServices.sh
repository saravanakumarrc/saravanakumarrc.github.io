﻿#!/bin/bash
ENV=${APP_ENV}
echo $ENV

export ConsumerConnectionOptions__Host="$(cat /kvmnt/$ENV-CONSUMER-CONN-HOST)"
export ConsumerConnectionOptions__EntityName="$(cat /kvmnt/$ENV-CONSUMER-CONN-ENTITYNAME)"
export ConsumerConnectionOptions__InboundSubscription="$(cat /kvmnt/$ENV-CONSUMER-CONN-INBOUNDSUBSCRIPTION)"
export ConsumerConnectionOptions__Key="$(cat /kvmnt/$ENV-CONSUMER-CONN-KEY)"
export ConsumerConnectionOptions__Username="$(cat /kvmnt/$ENV-CONSUMER-CONN-USERNAME)"

export DatabaseSettings__ConnectionString="$(cat /kvmnt/$ENV-DB-CONN-STRING)"
export DatabaseSettings__MaintenanceDatabaseName="$(cat /kvmnt/$ENV-MAINTENANCE-DB-NAME)"
export DatabaseSettings__CloudHubDatabaseName="$(cat /kvmnt/$ENV-CLOUDHUB-DB-NAME)"

export TtcConfigAuthOption__Authorization="$(cat /kvmnt/$ENV-TTC-AUTH-AUTHORIZATION)"
export TtcConfigAuthOption__BaseUrl="$(cat /kvmnt/$ENV-TTC-AUTH-BASE-URL)"
export TtcConfigAuthOption__ApiBaseUrl="$(cat /kvmnt/$ENV-TTC-AUTH-API-BASE-URL)"
export TtcConfigAuthOption__Content="$(cat /kvmnt/$ENV-TTC-AUTH-CONTENT)"
export TtcConfigAuthOption__ContentType="$(cat /kvmnt/$ENV-TTC-AUTH-CONTENT-TYPE)"
export TtcConfigAuthOption__GrantType="$(cat /kvmnt/$ENV-TTC-AUTH-GRANT-TYPE)"
export TtcConfigAuthOption__CodeKeyService="$(cat /kvmnt/$ENV-TTC-AUTH-CODE-KEY-SERVICE)"

export BackgroundQueueCount="$(cat /kvmnt/$ENV-BACKGROUND-QUEUE-COUNT)"
export SeriLog__MinimumLevel__Default="$(cat /kvmnt/$ENV-LOG-MINIMUM-LEVEL-DEFAULT)"

dotnet confighub.bridge.service.dll
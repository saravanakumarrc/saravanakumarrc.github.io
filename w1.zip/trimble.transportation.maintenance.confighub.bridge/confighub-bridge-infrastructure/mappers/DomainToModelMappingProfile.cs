﻿using AutoMapper;
using confighub.bridge.service.core.models;
using confighub.bridge.infrastructure.models;

namespace confighub.bridge.infrastructure.mapping
{
    /// <summary>
    /// AutoMapping for bind the DB entity and model. 
    /// </summary>
    public class DomainToModelMappingProfile : Profile
    {
        public DomainToModelMappingProfile()
        {
           CreateMap<IntegrationConfiguration, IntegrationConfigurationModel>();
           CreateMap<DataMapping, DataMappingModel>();            
           CreateMap<CodeKey, CodeKeyModel>();
        }
    }
}

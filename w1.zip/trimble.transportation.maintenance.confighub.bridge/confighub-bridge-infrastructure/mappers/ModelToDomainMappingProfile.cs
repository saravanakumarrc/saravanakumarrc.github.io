﻿using AutoMapper;
using confighub.bridge.service.core.models;
using confighub.bridge.infrastructure.models;

namespace confighub.bridge.infrastructure.mapping
{
    public class ModelToDomainMappingProfile : Profile
    {
        /// <summary>
        /// AutoMapping for bind the DB model and entity. 
        /// </summary>
        public ModelToDomainMappingProfile()
        {
            // CreateMap<BaseEntityModel, BaseEntity>();
            CreateMap<IntegrationConfigurationModel, IntegrationConfiguration>();
            CreateMap<DataMappingModel, DataMapping>();
            CreateMap<CodeKeyModel, CodeKey>();
        }
    }
}

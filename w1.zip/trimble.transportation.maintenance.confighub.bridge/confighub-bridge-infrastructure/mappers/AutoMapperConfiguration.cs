﻿using AutoMapper;

namespace confighub.bridge.infrastructure.mapping
{
    /// <summary>
    /// AutoMapperConfiguration for bind the DB entity and model. 
    /// </summary>
    public class AutoMapperConfiguration
    {
        public static IMapper Configure()
        {
            var config = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.AddProfile<DomainToModelMappingProfile>();
                cfg.AddProfile<ModelToDomainMappingProfile>();
            });

            return config.CreateMapper();
        }
    }
}

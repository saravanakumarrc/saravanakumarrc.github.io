﻿using confighub.bridge.service.core.interfaces;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace confighub.bridge.infrastructure.models
{
    public class Document : IDocument
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("is_active")]
        public bool IsActive { get; set; }

        [BsonElement("created_date")]
        public DateTime CreatedDate { get; set; }
        [BsonElement("created_by")]
        public string CreatedBy { get; set; }
        [BsonElement("modified_date")]
        public DateTime ModifiedDate { get; set; }
        [BsonElement("modified_by")]
        public string ModifiedBy { get; set; }

    }
}

﻿namespace confighub.bridge.infrastructure.models
{
    public class HttpServiceConstant
    {
        public const string ContentType = "application/json";        
    }
}

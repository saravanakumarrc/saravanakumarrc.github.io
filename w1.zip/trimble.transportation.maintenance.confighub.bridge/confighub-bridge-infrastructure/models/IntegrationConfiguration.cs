﻿using confighub.bridge.infrastructure.repositories;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace confighub.bridge.infrastructure.models
{
    [BsonCollection("integration_configuration")]
    public class IntegrationConfiguration : Document
    {
        [BsonElement("Tenant")]
        public string Tenant { get; set; }
        [BsonElement("NodeName")]
        public string NodeName { get; set; }
        [BsonExtraElements]
        public Dictionary<string, object> TenantDetails { get; set; }        
    }
}

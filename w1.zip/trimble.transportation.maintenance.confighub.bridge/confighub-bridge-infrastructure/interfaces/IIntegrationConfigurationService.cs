﻿using System.Collections.Generic;
using System.Threading.Tasks;
using confighub.bridge.service.core.models;
using confighub.bridge.infrastructure.models;

namespace confighub.bridge.infrastructure.interfaces
{
    public interface IIntegrationConfigurationService : IBaseService<IntegrationConfigurationModel, IntegrationConfiguration>
    {
        public Task<Dictionary<string, string>> GetTenantInformation(string nodeName);
        public Task<IList<IntegrationConfiguration>> GetAllAsync();
    }
}

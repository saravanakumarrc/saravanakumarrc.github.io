﻿using confighub.bridge.service.core.interfaces;
using confighub.bridge.infrastructure.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.interfaces
{
    public interface IDataRepository<TDocument> where TDocument : IDocument
    {
        void GetCollection(IDBContext dbContext);
        IQueryable<TDocument> AsQueryable();

        Task<IList<TDocument>> GetAllAsync();

        Task<IEnumerable<TDocument>> FilterBy(Expression<Func<TDocument, bool>> filterExpression, int? skip, int? limit);

        IEnumerable<TProjected> FilterBy<TProjected>(
            Expression<Func<TDocument, bool>> filterExpression,
            Expression<Func<TDocument, TProjected>> projectionExpression);
        Task<IList<TDocument>> FindAll(Expression<Func<TDocument, bool>> filterExpression);
        TDocument FindOne(Expression<Func<TDocument, bool>> filterExpression);

        Task<TDocument> FindOneAsync(Expression<Func<TDocument, bool>> filterExpression);

        TDocument FindById(string id);

        Task<TDocument> FindByIdAsync(string id);

        TDocument InsertOne(TDocument document);

        Task<TDocument> InsertOneAsync(TDocument document);

        ICollection<TDocument> InsertMany(ICollection<TDocument> documents);

        Task<ICollection<TDocument>> InsertManyAsync(ICollection<TDocument> documents);

        TDocument ReplaceOne(TDocument document);

        Task<TDocument> ReplaceOneAsync(TDocument document);

        void DeleteOne(Expression<Func<TDocument, bool>> filterExpression);

        Task<TDocument> DeleteOneAsync(Expression<Func<TDocument, bool>> filterExpression);

        void DeleteById(string id);
        Task<TDocument> DeleteByIdAsync(string id);

        void DeleteMany(Expression<Func<TDocument, bool>> filterExpression);

    }
}

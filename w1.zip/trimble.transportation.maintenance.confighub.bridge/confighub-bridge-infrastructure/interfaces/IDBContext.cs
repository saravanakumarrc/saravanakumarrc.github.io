﻿using MongoDB.Driver;
using System;

namespace confighub.bridge.infrastructure.interfaces
{
    public interface IDBContext
    {
        IMongoCollection<T> GetCollection<T>(Type collectionType);
    }
}

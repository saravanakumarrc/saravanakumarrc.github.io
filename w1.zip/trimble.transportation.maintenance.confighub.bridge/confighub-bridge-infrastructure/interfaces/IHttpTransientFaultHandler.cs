﻿using confighub.bridge.service.core.interfaces;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Net.Http;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.interfaces
{
    public interface IHttpTransientFaultHandler
    {
        public IAsyncPolicy<HttpResponseMessage> HttpRetryPolicy { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.interfaces
{
    public interface IMaintenanceDBContext:IDBContext
    {
    }
}

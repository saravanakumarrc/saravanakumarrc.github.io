﻿using confighub.bridge.service.core.interfaces;
using confighub.bridge.infrastructure.models;
using integration.services.kafka.shared.consumer;
using integration.services.kafka.shared.interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace confighub.bridge.infrastructure.wrappers
{
    public class ConsumerClientWrapper : IConsumerClientWrapper
    {
        private readonly IConsumer _consumer;
        private readonly ConsumerConnectionOptions _consumerConnectionOptions;

        public ConsumerClientWrapper(
            ILogger<IConsumerClientWrapper> logger, 
            IOptions<models.ConsumerConnectionOptions> serviceBusConnectionData,
            IServiceProvider serviceProvider)
        {
            _consumerConnectionOptions = serviceBusConnectionData.Value;
            _consumer = new Consumer(_consumerConnectionOptions, serviceProvider.GetRequiredService<ILogger<IConsumer>>());
        }

        public virtual async Task SubscribeAsync(Func<object, CancellationToken, Task> messageHandler, CancellationToken stopToken)
        {
            await _consumer.SubscribeAsync(_consumerConnectionOptions.EntityName, messageHandler, stopToken);
        }

       
    }
}

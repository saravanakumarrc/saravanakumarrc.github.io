﻿using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using MongoDB.Driver;
using System;
using System.Linq;

namespace confighub.bridge.infrastructure.repositories
{
    public class DBContext : IDBContext
    {
        protected MongoClient MongoClient { get; set; }
        protected IMongoDatabase DataBase { get; set; }
        public DBContext(IMongoDbSettings databaseSettings)
        {
            MongoClient = new MongoClient(databaseSettings.ConnectionString);
        }
        public IMongoCollection<T> GetCollection<T>(Type collectionType)
        {
            return DataBase.GetCollection<T>(GetCollectionName(collectionType));
        }

        private protected string GetCollectionName(Type documentType)
        {
            return ((BsonCollectionAttribute)documentType.GetCustomAttributes(
                    typeof(BsonCollectionAttribute),
                    true)
                .FirstOrDefault())?.CollectionName;
        }
    }
}

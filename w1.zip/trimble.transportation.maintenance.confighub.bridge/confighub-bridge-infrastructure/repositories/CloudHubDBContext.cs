﻿using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using MongoDB.Driver;

namespace confighub.bridge.infrastructure.repositories
{
    public class CloudHubDBContext : DBContext, ICloudHubDBContext
    {
        public CloudHubDBContext(IMongoDbSettings databaseSettings) : base(databaseSettings)
        {
            DataBase = MongoClient.GetDatabase(databaseSettings.CloudHubDatabaseName);
        }
    }
}

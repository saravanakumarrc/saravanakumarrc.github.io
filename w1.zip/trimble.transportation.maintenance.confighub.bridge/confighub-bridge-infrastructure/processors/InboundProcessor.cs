﻿using CloudNative.CloudEvents;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using confighub.bridge.service.core.services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog.Context;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.processors
{
    /// <summary>
    /// Class to register multiple consumer and process the inbound message. 
    /// </summary>
    public class InboundProcessor : IInboundProcessor
    {
        private readonly ILogger<IInboundProcessor> _logger;
        private readonly IBackgroundTaskQueue<object> _taskQueue;
        private readonly IServiceScope _scope;

        public InboundProcessor(ILogger<IInboundProcessor> logger, 
            IServiceProvider serviceProvider,
            IBackgroundTaskQueue<object> taskQueue)
        {
            _logger = logger;
            _scope = serviceProvider.CreateScope();
            _taskQueue = taskQueue;
        }

        public async Task ProcessReceivedMessage(object message, CancellationToken stoppingToken)
        {            
            var cloudEvent = message as CloudEvent;
            try
            {
                if (cloudEvent != null)
                {
                    using (LogContext.PushProperty("CorrId", cloudEvent.Id))
                    {
                        if (cloudEvent.Source is null)
                        {
                            _logger.LogWarning("Source information is missed in incoming message");
                            return;
                        }

                        if (cloudEvent.Data is not null)
                        {
                            var dataObject = JsonConvert.DeserializeObject<JObject>(cloudEvent.Data.ToString());

                            var messageInput = new Message
                            {
                                EventId = cloudEvent.Id,
                                EventType = cloudEvent.Type,
                                EventSource = cloudEvent.Source,
                                EventSubject = cloudEvent.Subject
                            };
                            
                            messageInput.AccountName = Convert.ToString(dataObject?["AccountName"])?.ToUpper();
                            messageInput.ExtendedProperties = JsonConvert.DeserializeObject<ExtendedProperties>(dataObject?["ExtendedProperties"]?.ToString());

                            var unitOfService = new UnitOfService(
                                _scope.ServiceProvider.GetRequiredService<ILogger<IUnitOfService>>(),
                                messageInput, 
                                _scope.ServiceProvider.GetRequiredService<ICodeKeyService>(),
                                _scope.ServiceProvider.GetRequiredService<ITokenService>(),
                                _scope.ServiceProvider.GetRequiredService<ICodeKeyValueService>(),
                                _scope.ServiceProvider.GetRequiredService<ICodeKeyLogService>()
                            );

                            await _taskQueue.EnqueueBackgroundWorkItemAsync(unitOfService.DoWorkAsync);
                        }
                        else
                        {
                            _logger.LogWarning($"Received empty msg body");
                        }
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
            }
            return;
        }      
    }
}

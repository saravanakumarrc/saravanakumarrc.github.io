using confighub.bridge.infrastructure.interfaces;
using Polly;
using Polly.Extensions.Http;
using Serilog;
using System;
using System.Net.Http;

namespace confighub.bridge.infrastructure.http
{
    public class HttpTransientFaultHandler : IHttpTransientFaultHandler
    {

        public IAsyncPolicy<HttpResponseMessage> HttpRetryPolicy { get; set; }
        public HttpTransientFaultHandler()
        {
            HttpRetryPolicy = HttpPolicyExtensions
                    .HandleTransientHttpError()
                    .WaitAndRetryAsync(
                        retryCount: 3,
                        sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                        onRetry: (exception, timespan, context) =>
                        {
                            Log.Error($"Retry {timespan}, due to: {exception?.Result}.");
                        });

        }
    }
}

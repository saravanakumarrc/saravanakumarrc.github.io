﻿using confighub.bridge.service.core.interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.http
{
    public enum GrantTypes
    {
        client_credentials,
        password
    }

    public class TtcConfigAuthentication
    {
        [JsonPropertyName("token_type")]
        public string TokenType { get; set; }

        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; }

        [JsonPropertyName("expires_in")]
        public int ExpirationTime { get; set; }
    }

    public class AuthTokenService : IAuthTokenService
    {
        private readonly IHttpService _httpservice;
        private readonly ILogger<AuthTokenService> _logger;

        public AuthTokenService(
            IHttpService httpservice,
            ILogger<AuthTokenService> logger)
        {
            _httpservice = httpservice;
            _logger = logger;
        }

        public async ValueTask<object> GetBearerTokenAsync(string baseUrl, string relativePath, string authorization, string grantType,
                                                                        string bodyContent, string contentType)
        {
            if (ConvertToGrantType(grantType) == GrantTypes.client_credentials)
            {
                List<KeyValuePair<string, string>> postData = new List<KeyValuePair<string, string>>();
                postData.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));

                var form = new FormUrlEncodedContent(postData);

                var headers = new Dictionary<string, string>()
                    {
                        { "Authorization", authorization }
                };

                var response = await _httpservice.PostAsync(baseUrl, relativePath, "", "application/x-www-form-urlencoded",
                        form, CancellationToken.None, headers);

                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        var responseData = JsonSerializer.Deserialize<TtcConfigAuthentication>(response.Content.ReadAsStringAsync().Result);

                        var bearerToken = responseData?.AccessToken;
                        if (!string.IsNullOrEmpty(bearerToken))
                        {
                            return bearerToken;
                        }
                        _logger.LogCritical("Unable to fetch auth token for accessing tenants api");
                        throw new Exception("Unable to get auth token for accessing tenants api");
                    }
                    catch (JsonException e)
                    {
                        _logger.LogError("Failed to parse json {@JsonException}", e);
                        throw new Exception(e.Message, e);
                    }
                }

                _logger.LogError("The request {baseUrl} Failed.", string.Concat(baseUrl, relativePath));
                throw new Exception(response.ToString());
            }

            return null;
        }


        private GrantTypes ConvertToGrantType(string value)
        {
            GrantTypes result;
            Enum.TryParse(value, out result);
            return result;
        }
    }
}
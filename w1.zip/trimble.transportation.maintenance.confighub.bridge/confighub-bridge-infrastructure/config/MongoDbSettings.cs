﻿using MongoDB.Driver;

namespace confighub.bridge.infrastructure.config
{
    /// <summary>
    /// Class to inject the connectionString and databaseName 
    /// </summary>   
    public class MongoDbSettings : IMongoDbSettings
    {
        public string MaintenanceDatabaseName { get; set; }
        public string ConnectionString { get; set; }
        public string CloudHubDatabaseName { get; set; }
        public MongoDbSettings()
        {
            MongoDefaults.GuidRepresentation = MongoDB.Bson.GuidRepresentation.Standard;
        }
    }
}

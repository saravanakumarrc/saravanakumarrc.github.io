﻿
namespace confighub.bridge.infrastructure.config
{    
    public interface IMongoDbSettings
    {
        string MaintenanceDatabaseName { get; set; }  //MaintenanceDB
        string ConnectionString { get; set; }
        string CloudHubDatabaseName { get; set; } //CloudnHubDB

    }
}

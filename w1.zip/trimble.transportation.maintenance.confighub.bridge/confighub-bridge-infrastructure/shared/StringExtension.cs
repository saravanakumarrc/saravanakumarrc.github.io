﻿namespace confighub.bridge.infrastructure.shared
{
    public static class StringExtension
    {
        public static string Encode(this string textToEncode)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(textToEncode);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string AuthBasic(this string textToEncode)
        {
            return string.Concat("Basic ", Encode(textToEncode));
        }
    }
}
﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.repositories;
using Newtonsoft.Json;

namespace confighub.bridge.infrastructure.services
{
    /// <summary>
    /// IntegrationConfigurationService for connect the repository
    /// </summary>
    public class IntegrationConfigurationService : BaseService<IntegrationConfigurationModel, IntegrationConfiguration>, IIntegrationConfigurationService
    {
        #region Private Variable
        private readonly IDataRepository<IntegrationConfiguration> _integrationConfigurationRepository;
        #endregion

        #region Constructor
        public IntegrationConfigurationService(IDataRepository<IntegrationConfiguration> integrationConfigurationRepository,
               ICloudHubDBContext dbContext, IMapper mapper) : base(integrationConfigurationRepository,
                   dbContext, mapper)
        {
            _integrationConfigurationRepository = integrationConfigurationRepository;
        }
        #endregion

        #region Methods
        public async Task<Dictionary<string, string>> GetTenantInformation(string nodeName)
        {
            Dictionary<string, string> tenantInformation = default;
            if (!string.IsNullOrEmpty(nodeName))
            {
                var integrationConfigurations = await FindOneAsync(x => x.NodeName == nodeName);
                var tenantDetailsAsString = integrationConfigurations != null ?
                    JsonConvert.SerializeObject(integrationConfigurations.TenantDetails[nodeName]) :
                    "";
                tenantInformation = !string.IsNullOrEmpty(tenantDetailsAsString) ?
                    JsonConvert.DeserializeObject<Dictionary<string, string>>(tenantDetailsAsString) : 
                    null;

            }
            return tenantInformation;
        }
        public async Task<IList<IntegrationConfiguration>> GetAllAsync()
        {
            var integrationConfigurations = await _integrationConfigurationRepository.FindAll(x => true);
            return integrationConfigurations;
        }
        #endregion Methods
    }
}

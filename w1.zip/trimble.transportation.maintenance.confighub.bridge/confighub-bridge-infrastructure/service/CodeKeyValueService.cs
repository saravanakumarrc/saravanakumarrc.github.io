﻿using confighub.bridge.core.constants;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using confighub.bridge.core.extentions;
using Microsoft.Extensions.Logging;
using confighub.bridge.infrastructure.models;
using confighub.bridge.service.core.exceptions;

namespace confighub.bridge.infrastructure.services
{
    /// <summary>
    /// Service to handle the GET/POST Methods related to the collection code keys
    /// </summary>
    public class CodeKeyValueService : ICodeKeyValueService
    {
        #region Private Variable

        private readonly ILogger<CodeKeyValueService> _logger;
        private readonly IHttpService _httpService;
        private readonly TtcConfigAuthOption _ttcConfigAuth;
        private readonly int _partitionCount = 3;
        #endregion

        #region Constructor
        public CodeKeyValueService(
            ILogger<CodeKeyValueService> logger,
            IHttpService httpService,
            IOptions<TtcConfigAuthOption> configAuthentication,
            IServiceProvider serviceProvider) 
        {
            _logger = logger;
            _httpService = httpService;
            _ttcConfigAuth = configAuthentication.Value;
            var config = serviceProvider.GetRequiredService<IConfiguration>();
            _partitionCount = config?.GetValue<int?>("PartitionCount") ?? 6;
        }
        #endregion

        /// <summary>
        /// Process each code key that are configured in DB, stores code key values
        /// </summary>
        /// <param name="codeKeys">List of code keys that are to be synced</param>
        /// <param name="bearerToken">Auth token to connect to cloudHub and code key api service</param>
        /// <param name="message">Message is being processed</param>
        /// <returns>result as code key log details</returns>
        public async Task<IList<CodeKeyLogDetail>> ProcessCodeKeysAsync(IList<CodeKeyModel> codeKeys, string bearerToken, IMessage message)
        {
            List<CodeKeyLogDetail> codeKeyResponse = new List<CodeKeyLogDetail>();

            var existingCodeKeyValues = await GetCodeKeyValues(message.EventSubject, bearerToken);

            var getTasks = codeKeys.Where(codeKey => codeKey.ResourceUrl is not null).Select(codeKey =>
                new Func<Task<CodeKeyLogDetail>>(() => ProcessAsync(bearerToken, codeKey, message, existingCodeKeyValues))).ToList();

            await ForEachAsyncSemaphore(getTasks, _partitionCount, async func =>
            {
                codeKeyResponse.Add(await func());
            });

            return codeKeyResponse;
        }

        /// <summary>
        /// Get the code key values from cloudhub and store to db using code key service
        /// </summary>
        /// <param name="bearerToken">Auth token to connect to cloudHub and code key service</param>
        /// <param name="codeKey">Codekey to be process</param>
        /// <param name="message">Input Message</param>
        /// <param name="codeKeyValues">existing code key values for update/create reference</param>
        /// <returns></returns>
        private async Task<CodeKeyLogDetail> ProcessAsync(string bearerToken, CodeKeyModel codeKey, IMessage message, IList<CodeKeyValueModel> codeKeyValues)
        {
            try
            {
                _logger.LogInformation($"From ResourceUrl {codeKey.MappingKey} {codeKey.ResourceUrl}");

                //Gets the cloudhub response based on the resource url specified in code key configuration.
                var cloudHubResponse = await _httpService.GetAsync(_ttcConfigAuth.ApiBaseUrl, codeKey.ResourceUrl,
                    bearerToken, CancellationToken.None);

                if (!cloudHubResponse.IsSuccessStatusCode)
                {
                    return new CodeKeyLogDetail { StatusCode = cloudHubResponse.StatusCode.ToInt(), MappingKey = codeKey.MappingKey, Error = await cloudHubResponse.Content.ReadAsStringAsync() };
                }

                var existingCodeKeyValue = codeKeyValues.FirstOrDefault(c => c.MappingKey == codeKey.MappingKey);

                //Building code key value based on the cloudHub response, if paginated then aggregated result will be returned.
                var codeKeyValue = await GetCodeKeyValueModel(codeKey, message, cloudHubResponse, existingCodeKeyValue, bearerToken);

                var path = string.Concat(_ttcConfigAuth.CodeKeyService, "codekeyvalues");

                //Put/Post the code key value model by using code key service endpoint
                HttpResponseMessage codeKeyValuesResponse = await PostCodeKeyValue(bearerToken, existingCodeKeyValue, path, codeKeyValue);

                if (!codeKeyValuesResponse.IsSuccessStatusCode)
                {
                    return new CodeKeyLogDetail { StatusCode =  codeKeyValuesResponse.StatusCode.ToInt(), MappingKey = codeKey.MappingKey, Error = await codeKeyValuesResponse.Content.ReadAsStringAsync() };
                }

                return new CodeKeyLogDetail() { StatusCode = codeKeyValuesResponse.StatusCode.ToInt(), MappingKey = codeKey.MappingKey };
            }
            catch (Exception exception)
            {
                _logger.LogError(message.EventId, exception, $"Error while processing code key {codeKey.MappingKey}");
                return new CodeKeyLogDetail() { StatusCode = 0, MappingKey = codeKey.MappingKey, Error = exception.Message };
            }
        }

        /// <summary>
        /// Building code key value based on the cloudHub response, if paginated then aggregated result will be returned.
        /// </summary>
        /// <param name="codeKey">code key to be processed</param>
        /// <param name="message">message</param>
        /// <param name="cloudHubResponse">cloudHub success response</param>
        /// <param name="existingCodeKeyValue">if found existing code key value of the mapping key</param>
        /// <param name="bearerToken">Auth token to be used</param>
        /// <returns></returns>
        /// <exception cref="DataValueNotFoundException"></exception>
        private async Task<CodeKeyValueModel> GetCodeKeyValueModel(CodeKeyModel codeKey, IMessage message,
            HttpResponseMessage cloudHubResponse, CodeKeyValueModel? existingCodeKeyValue, string bearerToken)
        {
            //deserialize the success response
            var cloudHubResponseString = await cloudHubResponse.Content.ReadAsStringAsync();
            var receivedDeserializeMessage = (JContainer) JsonConvert.DeserializeObject(cloudHubResponseString);

            //look for pagination information from cloud hub and transform to pagination information.
            var pagination = TransformToPaginationModel(receivedDeserializeMessage);

            //transforming the cloudhub response to data code key values
            var dataValues = TransformToDataValues(codeKey, receivedDeserializeMessage);
            
            //if pagination information is found and the pageCount is greater than 1 then further paginated cloudhub get call is required.
            if (pagination is not null && pagination?.PageCount > 1)
            {
                //initiate the cloudHub get call for each page( except first page, to all remaining pages to be fetched)
                var getDataValueFunctions = Enumerable.Range(2, pagination.PageCount - 1)
                    .Select(pageNo => new Func<Task<(IEnumerable<DataValue>, CodeKeyLogDetail)>>(() => 
                        GetDataValuesAsync(bearerToken, codeKey, message, pageNo))).ToList();

                //execute the get call and aggregate the data values, if any error found then DataValueNotFoundException will be returned
                await ForEachAsyncSemaphore(getDataValueFunctions, _partitionCount, async getDataValuesAsync =>
                {
                    var (dataValuesInner, codeKeyLogDetailInner) = await getDataValuesAsync();
                    
                    if (dataValuesInner?.Count() > 0)
                    {
                        dataValues.AddRange(dataValuesInner);
                    }
                    else if(codeKeyLogDetailInner?.Error is not null)
                    {
                        throw new DataValueNotFoundException(codeKeyLogDetailInner.Error, codeKey.MappingKey);
                    }
                });

                //after aggregation, if the result is different than the expected total record count then DataValueRecordCountMismatchException will be returned
                if (pagination?.TotalRecordCount != dataValues.Count)
                {
                    throw new DataValueRecordCountMismatchException( $"expected total record count {pagination.TotalRecordCount}, actual: {dataValues.Count}", codeKey.MappingKey);
                }
            }
            
            CodeKeyValueModel codeKeyValue = BuildCodeKeyValue(existingCodeKeyValue, codeKey, message, dataValues);

            return codeKeyValue;
        }

        /// <summary>
        /// Get paginated code key values
        /// </summary>
        /// <param name="bearerToken">Auth token to be used.</param>
        /// <param name="codeKey">syncing code key</param>
        /// <param name="message"></param>
        /// <param name="pageNo">pageNo to be used in get call.</param>
        /// <returns></returns>
        private async Task<(IEnumerable<DataValue>, CodeKeyLogDetail)> GetDataValuesAsync(string bearerToken, CodeKeyModel codeKey, IMessage message, int pageNo)
        {
            var dataValues = new List<DataValue>();
            try
            {
                var queryParams = codeKey.ResourceUrl.Replace("pageNo=1", $"pageNo={pageNo}");

                _logger.LogInformation($"From ResourceUrl {codeKey.MappingKey} {queryParams}");

                var cloudHubResponse = await _httpService.GetAsync(_ttcConfigAuth.ApiBaseUrl, queryParams,
                    bearerToken, CancellationToken.None);

                if (!cloudHubResponse.IsSuccessStatusCode)
                {
                    return (dataValues, new CodeKeyLogDetail { StatusCode = cloudHubResponse.StatusCode.ToInt(), MappingKey = codeKey.MappingKey, Error = await cloudHubResponse.Content.ReadAsStringAsync() });
                }

                var cloudHubResponseString = await cloudHubResponse.Content.ReadAsStringAsync();
                var receivedDeserializeMessage = (JContainer)JsonConvert.DeserializeObject(cloudHubResponseString);

                dataValues = TransformToDataValues(codeKey, receivedDeserializeMessage);

                return (dataValues, new CodeKeyLogDetail { StatusCode = cloudHubResponse.StatusCode.ToInt(), MappingKey = codeKey.MappingKey });
            }
            catch (Exception exception)
            {
                _logger.LogError(message.EventId, exception, $"Error while processing code key {codeKey.MappingKey}");
                return (dataValues, new CodeKeyLogDetail { StatusCode = 0, MappingKey = codeKey.MappingKey, Error = exception.Message });
            }
        }

        /// <summary>
        /// Put/Post the code key value model by using code key service endpoint
        /// </summary>
        /// <param name="bearerToken"></param>
        /// <param name="existingCodeKeyValue"></param>
        /// <param name="path"></param>
        /// <param name="newCodeKeyValue"></param>
        /// <returns></returns>
        private async Task<HttpResponseMessage> PostCodeKeyValue(string bearerToken, CodeKeyValueModel? existingCodeKeyValue, string path,
            CodeKeyValueModel newCodeKeyValue)
        {
            HttpResponseMessage codeKeyValuesResponse;
            if (existingCodeKeyValue is not null && !string.IsNullOrEmpty(existingCodeKeyValue.Id))
            {
                codeKeyValuesResponse = await _httpService.PutAsync(_ttcConfigAuth.ApiBaseUrl, path,
                    bearerToken,
                    JsonConvert.SerializeObject(newCodeKeyValue),
                    CancellationToken.None, null);
            }
            else
            {
                codeKeyValuesResponse = await _httpService.PostAsync(_ttcConfigAuth.ApiBaseUrl, path,
                    bearerToken,
                    AppConstants.HttpContentTypeJson,
                    JsonConvert.SerializeObject(newCodeKeyValue),
                    CancellationToken.None, null);
            }

            return codeKeyValuesResponse;
        }

        /// <summary>
        /// Executes the given list of task function asynchronously as per the given partitionCount
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tasks"></param>
        /// <param name="partitionCount"></param>
        /// <param name="callBackFunction"></param>
        /// <returns></returns>
        private Task ParallelForEachAsync<T>(IEnumerable<T> tasks,
                                                   int partitionCount,
                                                   Func<T, Task> callBackFunction)
        {
            // an inner function that executes the call back function of the given partition
            async Task AwaitPartition(IEnumerator<T> partition)
            {
                using (partition)
                {
                    while (partition.MoveNext())
                    {
                        await callBackFunction(partition.Current);
                    }
                }
            }

            // split the given task list to small partitions and executes parallely
            return Task.WhenAll(
              Partitioner.Create(tasks)
                  .GetPartitions(partitionCount)
                  .AsParallel()
                  .Select(AwaitPartition));
        }
        
        /// <summary>
        /// Transulates Json response to DataValues
        /// </summary>
        /// <param name="codeKey"></param>
        /// <param name="receivedDeserializeMessage"></param>
        /// <returns></returns>
        private List<DataValue> TransformToDataValues(CodeKeyModel codeKey, JContainer receivedDeserializeMessage)
        {
            var dataToken = receivedDeserializeMessage["data"];

            var data = dataToken.Select(d => MapToDataValue(codeKey.DataMapping, d)).ToList();

            return data;
        }

        /// <summary>
        /// mappings JToken to DataValue
        /// </summary>
        /// <param name="dataMapping"></param>
        /// <param name="d"></param>
        /// <returns></returns>
        private DataValue MapToDataValue(DataMappingModel dataMapping, JToken d)
        {
            return new DataValue
            {
                CodeId = d?[dataMapping?.CodeId]?.ToString(),
                Code = d?[dataMapping?.Code]?.ToString(),
                Description = d?[dataMapping?.Description]?.ToString()
            };
        }

        /// <summary>
        /// Transforms json response to pagination model
        /// </summary>
        /// <param name="receivedDeserializeMessage"></param>
        /// <returns></returns>
        private PaginationModel TransformToPaginationModel(JContainer receivedDeserializeMessage)
        {
            var jToken = receivedDeserializeMessage["pagination"];

            var paginationModel = MapToPagination(jToken);
            
            return paginationModel;
        }

        /// <summary>
        /// Map json token to pagination model.
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private PaginationModel MapToPagination(JToken token)
        {
            return new PaginationModel
            {
                PageNo = token?["pageNo"]?.Value<int>() ?? 0,
                PageSize = token?["pageSize"]?.Value<int>() ?? 0,
                PageCount = token?["pageCount"]?.Value<int>() ?? 0,
                TotalRecordCount = token?["totalRecordCount"]?.Value<int>() ?? 0,
            };
        }

        /// <summary>
        /// Building code key value model with createdBy, modifiedBy using the extended properties
        /// </summary>
        /// <param name="existingCodeKeyValue"></param>
        /// <param name="codeKey"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        private CodeKeyValueModel BuildCodeKeyValue(CodeKeyValueModel existingCodeKeyValue, CodeKeyModel codeKey, IMessage message, IEnumerable<DataValue> data)
        {
            return new CodeKeyValueModel
            {
                Id = existingCodeKeyValue?.Id,
                AccountId = message.EventSubject,
                MappingKey = codeKey.MappingKey,
                IsActive = true,
                DataValues = data,
                CreatedBy = existingCodeKeyValue?.CreatedBy ?? message?.ExtendedProperties?.CreatedBy,
                CreatedDate = existingCodeKeyValue?.CreatedDate ?? message?.ExtendedProperties?.CreatedDate ?? DateTime.UtcNow,
                ModifiedBy = message?.ExtendedProperties?.ModifiedBy,
                ModifiedDate = message?.ExtendedProperties?.ModifiedDate ?? DateTime.UtcNow,
            };
        }

        /// <summary>
        /// Gets the Code Key values of the given accountId
        /// </summary>
        /// <param name="accountId">accountId of the synching user</param>
        /// <param name="bearerToken">Auth token to connect to code key api service</param>
        /// <returns></returns>
        private async Task<IList<CodeKeyValueModel>> GetCodeKeyValues(string accountId, string bearerToken)
        {
            var path = $"maintenance/v1/codekey/accounts/{accountId}/codekeyvalues";

            var codeKeyResponse = await _httpService.GetAsync(_ttcConfigAuth.ApiBaseUrl, path,
            bearerToken, CancellationToken.None, null);

            if (codeKeyResponse.IsSuccessStatusCode)
            {
                var codeKeyValuesContent = await codeKeyResponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<CodeKeyValueModel>>(codeKeyValuesContent);
            }

            return new List<CodeKeyValueModel>();
        }

        public async Task ForEachAsyncSemaphore<T>(IEnumerable<T> source, int degreeOfParallelism, Func<T, Task> body)
        {
            var tasks = new List<Task>();
            using (var throttler = new SemaphoreSlim(degreeOfParallelism))
            {
                foreach (var element in source)
                {
                    await throttler.WaitAsync();
                    tasks.Add(Task.Run(async () =>
                    {
                        try
                        {
                            await body(element);
                        }
                        finally
                        {
                            throttler.Release();
                        }
                    }));
                }
                await Task.WhenAll(tasks);
            }
        }
    }
}

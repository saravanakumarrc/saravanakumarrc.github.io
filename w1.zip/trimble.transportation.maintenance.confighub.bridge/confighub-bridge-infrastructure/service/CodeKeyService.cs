﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.models;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;

namespace confighub.bridge.infrastructure.services
{
    /// <summary>
    /// Service to handle the GET/POST Methods related to the collection code keys
    /// </summary>
    public class CodeKeyService : ICodeKeyService
    {
        #region Private Variable
        private readonly IDataRepository<CodeKey> _codeKeyRepository;
        private readonly IMapper _mapper;
        #endregion

        #region Constructor
        public CodeKeyService(IDataRepository<CodeKey> codeKeyRepository, IMaintenanceDBContext dbContext, IMapper mapper) 
        {
            _codeKeyRepository = codeKeyRepository;
            _codeKeyRepository.GetCollection(dbContext);
            _mapper = mapper;
        }
        #endregion

        /// <summary>
        /// Get all codeKeys
        /// </summary>
        /// <returns>List of codeKeys</returns>
        public async Task<IList<CodeKeyModel>> GetAsync()
        {
            var codeKeys = await _codeKeyRepository.FindAll(c => c.IsActive == true);

            return _mapper.Map<IList<CodeKeyModel>>(codeKeys);
        }
    }
}

﻿using confighub.bridge.core.constants;
using confighub.bridge.infrastructure.http;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.services;
using confighub.bridge.infrastructure.shared;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.infrastructure.services
{
    public class TokenService : ITokenService
    {
        private readonly IIntegrationConfigurationService _integrationConfigurationService;
        private readonly IAuthTokenService _authTokenService;
        private readonly TtcConfigAuthOption _ttcConfigAuth;
        private readonly ILogger<TokenService> _logger;

        public TokenService(IIntegrationConfigurationService integrationConfigurationService, 
            IAuthTokenService authTokenService,
            IOptions<TtcConfigAuthOption> configAuthentication,
            ILogger<TokenService> logger)
        {
            _integrationConfigurationService = integrationConfigurationService;
            _authTokenService = authTokenService;
            _ttcConfigAuth = configAuthentication.Value;
            _logger = logger;
        }

        public async Task<string> GetTokenAsync(string accountName)
        {
            string bearerToken = string.Empty;
            
            //read the account name from the response object, "name" is the property
            string searchParam = string.Format(AppConstants.TrimbleIdSearchParam, accountName);

            var integrationConfigurations = await _integrationConfigurationService.GetTenantInformation(searchParam);
            
            if (integrationConfigurations != null 
                && integrationConfigurations.Count > 0 
                && integrationConfigurations.ContainsKey("CLIENT_KEY")
                && integrationConfigurations.ContainsKey("CLIENT_SECRET")
                && !string.IsNullOrEmpty(integrationConfigurations["CLIENT_KEY"])
                && !string.IsNullOrEmpty(integrationConfigurations["CLIENT_SECRET"]))
            {
                //extract client key and secret from customer trimble basic information and generate a new token                    
                bearerToken = Convert.ToString(await _authTokenService.GetBearerTokenAsync(_ttcConfigAuth.BaseUrl, _ttcConfigAuth.BaseUrl,
                                        string.Concat(integrationConfigurations["CLIENT_KEY"], ":",
                                        integrationConfigurations["CLIENT_SECRET"]).AuthBasic(),
                                        _ttcConfigAuth.GrantType, null, _ttcConfigAuth.ContentType));
                return bearerToken;
            }
            else
            {
                _logger.LogError($"{accountName} Information is not available");
            }

            return bearerToken;
        }
    }
}

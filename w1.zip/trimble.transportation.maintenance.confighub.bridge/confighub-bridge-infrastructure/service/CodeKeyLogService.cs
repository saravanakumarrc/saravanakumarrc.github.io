﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using confighub.bridge.core.constants;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using confighub.bridge.service.core.enums;
using System.Net.Http;

namespace confighub.bridge.infrastructure.services
{
    /// <summary>
    /// Service to handle the GET/POST Methods related to the collection code keys
    /// </summary>
    public class CodeKeyLogService : ICodeKeyLogService
    {
        #region Private Variable
        private readonly IHttpService _httpService;
        private readonly TtcConfigAuthOption _ttcConfigAuth;
        #endregion

        #region Constructor
        public CodeKeyLogService(
            IHttpService httpService,
            IOptions<TtcConfigAuthOption> configAuthentication) 
        {
            _httpService = httpService;
            _ttcConfigAuth = configAuthentication.Value;
        }
        #endregion

        public async Task<HttpResponseMessage> PostAsync(string bearerToken, IList<CodeKeyLogDetail> details, IMessage message)
        {
            var codeKeyLog = BuildCodeKeyLog(details, message);
            var path = string.Concat(_ttcConfigAuth.CodeKeyService, "codekeylogs");

            return await _httpService.PostAsync(_ttcConfigAuth.ApiBaseUrl, path,
                                                bearerToken,
                                                AppConstants.HttpContentTypeJson,
                                                JsonConvert.SerializeObject(codeKeyLog),
                                                CancellationToken.None, null);
        }

        private CodeKeyLogModel BuildCodeKeyLog(IList<CodeKeyLogDetail> details, IMessage message)
{
            return new CodeKeyLogModel
            {
                EventId = message.EventId,
                AccountId = message.EventSubject,
                CreatedBy = message?.ExtendedProperties?.CreatedBy,
                CreatedDate = message?.ExtendedProperties?.CreatedDate ?? DateTime.UtcNow,
                ModifiedBy = message?.ExtendedProperties?.ModifiedBy,
                ModifiedDate = message?.ExtendedProperties?.ModifiedDate ?? DateTime.UtcNow,
                Status = GetStatus(details).ToString(),
                Details = details
            };
        }

        private CodeKeyLogStatus GetStatus(IList<CodeKeyLogDetail> details)
        {
            if (details.All(r => !string.IsNullOrWhiteSpace(r.Error)))
            {
                return CodeKeyLogStatus.Failure;
            }
            if (details.Any(r => !string.IsNullOrWhiteSpace(r.Error)))
            {
                return CodeKeyLogStatus.PartialFailure;
            }
            return CodeKeyLogStatus.Success;
        }
    }
}

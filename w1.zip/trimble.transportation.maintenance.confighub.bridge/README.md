This project was created with the [Worker Service](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/host/hosted-services?view=aspnetcore-5.0&tabs=visual-studio) template.


A collaborative design document can be found here: [Edge Connector](https://docs.google.com/document/d/1EeFOdreXMFhjPZr45Z4_ZF7ed5QgAkWMWAdoDhCRNvE/edit?usp=sharing)

Overview
With Clean Architecture, the Domain and Application layers are at the centre of the design. This is known as the Core of the system.

The Domain layer contains enterprise logic and types and the Application layer contains business logic and types. The difference is that enterprise logic could be shared across many systems, whereas the business logic will typically only be used within this system.

Core should not be dependent on data access and other infrastructure concerns so those dependencies are inverted. This is achieved by adding interfaces or abstractions within Core that are implemented by layers outside of Core. For example, if you wanted to implement the Repository pattern you would do so by adding an interface within Core and adding the implementation within Infrastructure.

All dependencies flow inwards and Core has no dependency on any other layer. Infrastructure and Presentation depend on Core, but not on one another.


Project Folder Structure

These project has three layers:

1) Presentation Layer - confighub-bridge-service

Shell for hosting the worker service.

2) Core Layer - confighub-bridge-core

Core Layer. Development of Domain Logic with abstraction. Interfaces drives business requirements with light implementation. The Core project is the center of the Clean Architecture design, and all other project dependencies should point toward it.

Add the factory, model, interfaces etc.,

3) Infrastructure Layer - confighub-bridge-infrastructure

Core should not be dependent on data access and other infrastructure concerns so those dependencies are inverted. This is achieved by adding interfaces or abstractions within Core that are implemented by layers outside of Core. For example, if you wanted to implement the Repository pattern you would do so by adding an interface within Core and adding the implementation within Infrastructure.

Add the implementation of messaging, data access, http client service 


Reference:
https://devintxcontent.blob.core.windows.net/showcontent/Speaker%20Presentations%20Fall%202019/Clean%20Architecture%20with%20ASP.NET%20Core%20(1).pdf

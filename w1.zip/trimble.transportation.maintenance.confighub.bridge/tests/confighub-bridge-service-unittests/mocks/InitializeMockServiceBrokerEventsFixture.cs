﻿using AutoMapper;
using confighub.bridge.service.core.models;
using confighub.bridge.service.core.services;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.services;
using confighub.bridge.infrastructure.wrappers;
using confighub.bridge.service.unittests.mocks.data;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockServiceBrokerEventsFixture 
    {
        //public Mock<ServiceBrokerEventService> MockServiceBrokerEventService { get; }
        //public Mock<IMapper> MockMapper { get; }
        //public Mock<RepositoryWrapper<ServiceBrokerEventModel>> MockRepositoryWrapper { get; }
        //public Mock<IMongoDbSettings> MockMongoDbSettings { get; }
        //public Mock<ServiceBrokerEventMockData> MockServiceBrokerEventMockData { get; }

        //public InitializeMockServiceBrokerEventsFixture()
        //{
        //    MockMapper = new Mock<IMapper>();
        //    MockMongoDbSettings = new Mock<IMongoDbSettings>();
        //    MockRepositoryWrapper = new Mock<RepositoryWrapper<ServiceBrokerEventModel>>(MockMongoDbSettings.Object, MockMapper.Object);
        //    MockServiceBrokerEventService = new Mock<ServiceBrokerEventService>(MockRepositoryWrapper.Object);
        //    MockServiceBrokerEventMockData = new Mock<ServiceBrokerEventMockData>();

        //}
    }
}

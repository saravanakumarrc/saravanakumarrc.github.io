﻿using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.services;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using confighub.bridge.service.core.models;
using confighub.bridge.service.unittests.mocks.data;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockQueuedHostedServiceFixture
    {
        public Mock<ILogger<QueuedHostedService>> MockLoggerQueuedHostedService { get; }
        public Mock<BackgroundTaskQueue<object>> MockBackgroundTaskQueue { get; }
        public Mock<IHttpService> MockHttpService { get; }
        public Mock<IAuthTokenService> MockAuthTokenService { get; }
        public Mock<IOptions<TtcConfigAuthOption>> MockTtcConfigAuthentication { get; }
       
        public InitializeMockQueuedHostedServiceFixture()
        { 
            MockLoggerQueuedHostedService = new Mock<ILogger<QueuedHostedService>>();
            MockBackgroundTaskQueue = new Mock<BackgroundTaskQueue<object>>(1) { CallBase = true };
            MockHttpService = new Mock<IHttpService>();
            MockAuthTokenService = new Mock<IAuthTokenService>();
            MockTtcConfigAuthentication = new Mock<IOptions<TtcConfigAuthOption>>();
        }
    }
}

﻿using Moq;
using Microsoft.Extensions.Logging;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.unittests.mocks.data;
using confighub.bridge.infrastructure.http;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockAuthTokenServiceFixture
    {
        public Mock<IHttpService> MockIHttpService { get; }
        public Mock<ILogger<AuthTokenService>> MockAuthTokenServiceLogger { get; }
        public Mock<IAuthTokenService> MockAuthTokenService { get; }
        public Mock<AuthTokenServiceMockData> MockAuthTokenServiceMockData { get; }
        public InitializeMockAuthTokenServiceFixture()
        {
            MockIHttpService = new Mock<IHttpService>();
            MockAuthTokenServiceLogger = new Mock<ILogger<AuthTokenService>>();
            MockAuthTokenService = new Mock<IAuthTokenService>();
            MockAuthTokenServiceMockData = new Mock<AuthTokenServiceMockData>();
        }          
    }
}


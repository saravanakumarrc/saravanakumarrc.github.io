﻿using AutoMapper;
using System.Collections.Generic;
using Moq;
using MongoDB.Driver;
using Microsoft.Extensions.Logging.Abstractions;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.service.unittests.mocks.data;
using confighub.bridge.infrastructure.services;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.repositories;
using confighub.bridge.infrastructure.http;
using Moq.Protected;
using System.Net.Http;
using System.Net;
using System.Threading.Tasks;
using System.Threading;
using confighub.bridge.service.core.models;
using Microsoft.Extensions.Options;
using confighub.bridge.service.core.interfaces;
using System;
using confighub.bridge.service.core.services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockCodeKeyLogFixture
    {
        public Mock<IHttpClientFactory> MockIhttpClientFactory { get; }
        public Mock<HttpMessageHandler> MockHttpMessageHandler { get; }
        public Mock<IHttpTransientFaultHandler> MockHttpTransientFaultHandler { get; }
        public HttpClient HttpClient { get; }
        public Mock<IHttpService> MockHttpService { get; }
        public Mock<IOptions<TtcConfigAuthOption>> MockTtcConfigAuthentication { get; }
        public IMessage Message { get; }
        public Mock<CodeKeyLogMockData> MockData { get; }

        public InitializeMockCodeKeyLogFixture()
        {
            MockIhttpClientFactory = new Mock<IHttpClientFactory>();
            MockIhttpClientFactory.Setup(x => x.CreateClient(HttpServiceMockData.BaseURL)).Returns(new HttpClient());

            MockHttpMessageHandler = new Mock<HttpMessageHandler>();
            MockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(HttpServiceMockData.HttpMessageHandleType, ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage { StatusCode = HttpStatusCode.OK });

            HttpClient = new HttpClient(MockHttpMessageHandler.Object);

            MockHttpTransientFaultHandler = new Mock<IHttpTransientFaultHandler>();

            MockHttpService = new Mock<IHttpService>();
            MockTtcConfigAuthentication = new Mock<IOptions<TtcConfigAuthOption>>();

            MockData = new Mock<CodeKeyLogMockData>();
        }
    }
}

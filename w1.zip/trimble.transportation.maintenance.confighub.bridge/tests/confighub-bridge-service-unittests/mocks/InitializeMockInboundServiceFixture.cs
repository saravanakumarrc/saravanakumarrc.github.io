﻿using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.processors;
using confighub.bridge.service.unittests.mocks.data;
using confighub.bridge.service.core.services;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using confighub.bridge.infrastructure.http;
using confighub.bridge.infrastructure.services;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.repositories;
using confighub.bridge.infrastructure.wrappers;
using integration.services.kafka.shared.interfaces;
using Microsoft.Extensions.Configuration;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockInboundServiceFixture
    {
        public Mock<IOptions<ConsumerConnectionOptions>> MockListenerServiceBusConnectionData { get; }
        public Mock<IOptions<TtcConfigAuthOption>> MockTtcConfigAuthOption { get; }
        public Mock<InboundProcessor> MockInboundProcessor { get; }
        public Mock<InboundServiceMockData> MockData { get; }
        public Mock<ILogger<InboundService>> MockLogger { get; }
        public Mock<ILogger<IInboundProcessor>> MockLoggerInboundProcessor { get; }
        public Mock<BackgroundTaskQueue<object>> MockTaskQueue { get; }
        public Mock<IConsumerClientWrapper> MockConsumerClientWrapper { get; }
        public Mock<IMessage> MockMessage { get; }
        public Mock<ILogger<IUnitOfService>> MockIUnitOfServiceLogger { get; }
        public Mock<ICodeKeyService> MockCodeKeyService { get; }
        public Mock<ICodeKeyValueService> MockCodeKeyValueService { get; }
        public Mock<ICodeKeyLogService> MockCodeKeyLogService { get; }
        public Mock<ITokenService> MockTokenService { get; }
        public Mock<IHttpService> MockHttpService { get; }

        public InitializeMockInboundServiceFixture()
        {
            var service = new ServiceCollection();
            service.AddScoped<ILoggerFactory, LoggerFactory>();
            service.AddScoped<IMessage, Message>();
            service.AddScoped<TtcConfigAuthOption>();

            service.Configure<TtcConfigAuthOption>((data) =>
            {

            });
            service.AddHttpClient();
            service.AddScoped<IUnitOfService, UnitOfService>();
            service.AddTransient<ICodeKeyService, CodeKeyService>();
            service.AddTransient<ICodeKeyValueService, CodeKeyValueService>();
            service.AddTransient<ICodeKeyLogService, CodeKeyLogService>();
            service.AddScoped<ILogger<IUnitOfService>, Logger<UnitOfService>>();
            service.AddScoped<IHttpService, HttpService>();
            service.AddScoped<IAuthTokenService, AuthTokenService>(); 
            service.AddSingleton<IConfiguration>(new ConfigurationBuilder().Build());
            var provider = service.BuildServiceProvider();

            MockListenerServiceBusConnectionData = new Mock<IOptions<ConsumerConnectionOptions>>();
            MockTtcConfigAuthOption = new Mock<IOptions<TtcConfigAuthOption>>();
            MockLoggerInboundProcessor = new Mock<ILogger<IInboundProcessor>>();
            MockTaskQueue = new Mock<BackgroundTaskQueue<object>>(1);
            MockConsumerClientWrapper = new Mock<IConsumerClientWrapper>();

            MockInboundProcessor = new Mock<InboundProcessor>(MockLoggerInboundProcessor.Object, provider, MockTaskQueue.Object);
            MockData = new Mock<InboundServiceMockData>();
            MockLogger = new Mock<ILogger<InboundService>>();
            MockCodeKeyService = new Mock<ICodeKeyService>();
            MockCodeKeyValueService = new Mock<ICodeKeyValueService>();
            MockCodeKeyLogService = new Mock<ICodeKeyLogService>();
            MockTokenService = new Mock<ITokenService>();
            MockHttpService = new Mock<IHttpService>();

            MockIUnitOfServiceLogger = new Mock<ILogger<IUnitOfService>>();
            MockMessage = new Mock<IMessage>();
        }
    }
}

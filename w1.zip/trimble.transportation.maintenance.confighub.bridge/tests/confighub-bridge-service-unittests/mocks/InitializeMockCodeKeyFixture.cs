﻿using AutoMapper;
using System.Collections.Generic;
using Moq;
using MongoDB.Driver;
using Microsoft.Extensions.Logging.Abstractions;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.config;
using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.service.unittests.mocks.data;
using confighub.bridge.infrastructure.services;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.repositories;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockCodeKeyFixture
    {
        public Mock<IDataRepository<CodeKey>> MockCodeKeyRepository { get; }
        public Mock<CodeKeyService> MockCodeKeyService { get; }
        public Mock<CodeKeyMockData> MockData { get; }
        public Mock<IMaintenanceDBContext> MockMaintenanceDBContext { get; }
        public Mock<IMongoDbSettings> MockDatabaseSettings { get; }
        public IMapper Mapper { get; }
        public Mock<IMongoCollection<CodeKey>> MockCodeKey { get; } 
        public InitializeMockCodeKeyFixture()
        {
            MockData = new Mock<CodeKeyMockData>();
            MockMaintenanceDBContext = new Mock<IMaintenanceDBContext>();
            MockDatabaseSettings = new Mock<IMongoDbSettings>();
            Mapper = AutoMapperConfiguration.Configure();
            MockCodeKeyRepository = new Mock<IDataRepository<CodeKey>>();
            //MockCodeKeyService = new Mock<CodeKeyService>(MockCodeKeyRepository.Object, MockConfigurationHubContext.Object, Mapper);
            MockCodeKey = new Mock<IMongoCollection<CodeKey>>();
        }
    }
}

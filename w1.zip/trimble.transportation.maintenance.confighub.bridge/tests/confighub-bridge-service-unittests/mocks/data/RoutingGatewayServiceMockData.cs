﻿using confighub.bridge.service.core.models;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class RoutingGatewayServiceMockData
    {
        public const string BearerToken = "";       
        public async ValueTask<HttpResponseMessage> GetPostData()
        {
            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                RequestMessage = new HttpRequestMessage()
            };
        }

        public TtcConfigAuthOption GetMockTtcConfigAuthentication()
        {
            return new TtcConfigAuthOption
            {
                Authorization = "Basic OTk1NTk2MkFhZDk3RGRGMGQ5NDQyO",
                BaseUrl = "https://cloud.dev.api.trimblecloud.com/transportation/api/identity/v2/oauth2/token",
                Content = "application/x-www-form-urlencoded",
                ContentType = "application/x-www-form-urlencoded",
                GrantType = "client_credentials"
            };
        }

    }
}

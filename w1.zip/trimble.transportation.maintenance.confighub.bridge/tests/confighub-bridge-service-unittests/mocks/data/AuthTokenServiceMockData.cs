﻿using confighub.bridge.infrastructure.http;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class AuthTokenServiceMockData
    {
        public TtcConfigAuthentication getTtcConfigAuthentication()
        {
            return new TtcConfigAuthentication
            {
                AccessToken = "OTk1NTk2MkFhZDk3RGRGMGQ5",
                ExpirationTime = 20,
                TokenType = "JWT"
            };
        }
        public async ValueTask<HttpResponseMessage> GetPostData()
        {
            var _ttcConfigAuthentication = getTtcConfigAuthentication();
            var jsonString = JsonConvert.SerializeObject(_ttcConfigAuthentication);
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            
            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                RequestMessage = new HttpRequestMessage(),
                Content = content
            };
        } 
    }
}

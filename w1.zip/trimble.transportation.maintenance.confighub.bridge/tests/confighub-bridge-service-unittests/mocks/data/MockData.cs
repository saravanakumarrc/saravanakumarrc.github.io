﻿using CloudNative.CloudEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class MockData
    {

        public CloudEvent EventMessageData()
        {

            var couldEvent = new CloudEvent();
            couldEvent.Id = Guid.NewGuid().ToString();
            couldEvent.Source = new Uri($"http://{Assembly.GetExecutingAssembly().GetName().Name}.com");
            couldEvent.Subject = "Test";
            couldEvent.Type = "Test-ServiceBroker";
            string ftpMessage = "{\"Source\":{\"$type\": \"FtpCredential\",\"Location\": \"tmt.tmwcloud.com\",\"User\": \"tmt_sup\",\"password\": \"efij7750\"," +
                                "                               \"grantType\": \"client_credentials\",\"FileName\": \"RonFinemoreRepairInvoiceXML.xml\",\"FolderName\": \"\",\"IsSftp\": \"true\"}," +
                                "                               \"Destination\": {\"$type\": \"QueueCredential\",\"Host\": \"pkc-4k6zp.eastus2.azure.confluent.cloud:9092\", \"UserName\": \"Test user \" , \"Key\": \" 8SsReLkTGfsgRm98nY1QjF6AFxpz69PIKeuCbdkRoIVucw+OSez1f3WrcpmCEJfu \",\"InboundSubscription\": \"dev-maintenance-integration-services-bridge \" , " +
                                "                               \"EntityName\": \"dev.trimble.transportation.maintenance.repair-invoice.created.qry.v1\",\"Port\": \"9092\" }}";
            couldEvent.Data = ftpMessage;

            return couldEvent;
        }
    }
}

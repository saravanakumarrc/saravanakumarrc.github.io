﻿using confighub.bridge.infrastructure.http;
using confighub.bridge.infrastructure.models;
using confighub.bridge.service.core.models;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using confighub.bridge.infrastructure.services;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class CodeKeyLogMockData
    {
        public CodeKeyLogMockData()
        {
        }

        public IList<CodeKeyLogDetail> GetMockCodeKeyResultModels()
        {
            return new List<CodeKeyLogDetail>()
            {
                new CodeKeyLogDetail()
                {
                    MappingKey = "ADDITIVE",
                    StatusCode = 201,
                    Error = String.Empty
                },
                new CodeKeyLogDetail()
                {
                    MappingKey = "REPAIRSITE",
                    StatusCode = 201,
                    Error = String.Empty
                }
            };
        }

        public Message MockMessage= new Message
        {
            AccountName = "TRIMBLE",
            EventId = Guid.NewGuid().ToString(),
            EventSource = new Uri("https://maintenance-configurationhub.dev.trimble-transportation.com/"),
            EventSubject = Guid.NewGuid().ToString(),
            EventType = "confighub.qry",
            ExtendedProperties = new ExtendedProperties
            {
                CreatedBy = "TESTUSER",
                ModifiedBy = "TESTUSER",
                CreatedDate = DateTime.UtcNow,
                ModifiedDate = DateTime.UtcNow
            }
        };

        public CodeKeyLogModel GetCodeKeyLogModel()
        {
            return new CodeKeyLogModel
            {
                EventId = MockMessage.EventId,
                AccountId = MockMessage.EventSubject,
                CreatedBy = MockMessage?.ExtendedProperties?.CreatedBy,
                CreatedDate = MockMessage?.ExtendedProperties?.CreatedDate ?? DateTime.UtcNow,
                ModifiedBy = MockMessage?.ExtendedProperties?.ModifiedBy,
                ModifiedDate = MockMessage?.ExtendedProperties?.ModifiedDate ?? DateTime.UtcNow,
                Status = "Success",
                Details = new List<CodeKeyLogDetail>()
            };
        }

        public async ValueTask<HttpResponseMessage> GetPostData()
        {
            var codeKeyLogModel = GetCodeKeyLogModel();
            var jsonString = JsonConvert.SerializeObject(codeKeyLogModel);
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Created,
                RequestMessage = new HttpRequestMessage(),
                Content = content
            };
        }
        public TtcConfigAuthOption MockTtcConfigAuthOption = new TtcConfigAuthOption
        {
            ApiBaseUrl = "https://cloud.dev.api.trimblecloud.com/transportation/",
            Content = "application/x-www-form-urlencoded",
            ContentType = "application/x-www-form-urlencoded",
            CodeKeyService = "maintenance/v1/codekey/"
        };
    }
}

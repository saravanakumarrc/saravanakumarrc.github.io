﻿using System;
using System.Collections.Generic;
using System.Reflection;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.Kafka;
using CloudNative.CloudEvents.NewtonsoftJson;
using confighub.bridge.infrastructure.models;
using integration.services.kafka.shared.converters;
using Newtonsoft.Json;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class InboundServiceMockData
    {

        public InboundServiceMockData()
        {

        }

        public ConsumerConnectionOptions GetMockServiceBusConnectionData()
        {
            return new ConsumerConnectionOptions()
            {
                Host = "integrationexample.servicebus.windows.net",
                Port = 5671,
                EntityName = "integrationqueue",
                InboundSubscription = null,
                Username = "policyintegrationqueue",
                Key = "3pEU+vjXpS2j9zu3RhzeVWmjmZq8ylvrZmUJL1utmTo=",
            };
        }

        public CloudEvent EventMessageData()
        {

            var couldEvent = new CloudEvent();
            couldEvent.Id = Guid.NewGuid().ToString();
            couldEvent.Source = new Uri($"http://{Assembly.GetExecutingAssembly().GetName().Name}.com");
            couldEvent.Subject = "Test";

            string ftpMessage = "{\"Source\":{\"$type\": \"FtpCredential\",\"Location\": \"tmt.tmwcloud.com\",\"User\": \"tmt_sup\",\"password\": \"efij7750\"," +
                                "                               \"grantType\": \"client_credentials\",\"FileName\": \"RonFinemoreRepairInvoiceXML.xml\",\"FolderName\": \"\",\"IsSftp\": \"true\"}," +
                                "                               \"Destination\": {\"$type\": \"QueueCredential\",\"Host\": \"pkc-4k6zp.eastus2.azure.confluent.cloud:9092\", \"UserName\": \"Test user \" , \"Key\": \" 8SsReLkTGfsgRm98nY1QjF6AFxpz69PIKeuCbdkRoIVucw+OSez1f3WrcpmCEJfu \",\"InboundSubscription\": \"dev-maintenance-integration-services-bridge \" , " +
                                "                               \"EntityName\": \"dev.trimble.transportation.maintenance.repair-invoice.created.qry.v1\",\"Port\": \"9092\" }}";
            couldEvent.Data = ftpMessage;
          
            return couldEvent;
        }

    }
}

﻿namespace confighub.bridge.service.unittests.mocks.data
{
    public class HttpServiceMockData
    {
        public const string BaseURL = "https://cloud.dev.api.trimblecloud.com/transportation/maintenance/v1/integrationgroups";
        public const string ContentType = "application / json";
        public const string HttpMessageHandleType = "SendAsync";
    }
}

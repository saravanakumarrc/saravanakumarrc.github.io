﻿using confighub.bridge.infrastructure.models;
using confighub.bridge.service.core.models;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;

namespace confighub.bridge.service.unittests.mocks.data
{
    public class CodeKeyMockData
    {

        private Mock<IMongoCollection<CodeKey>> CodeKeys { get; }

        public CodeKeyMockData()
        {
            CodeKeys = new Mock<IMongoCollection<CodeKey>>();

        }

        public IList<CodeKeyModel> GetMockCodeKeyModels()
        {
            return new List<CodeKeyModel>()
            {
                new CodeKeyModel()
                {
                    Id = "1",
                    MappingKey = "ADDITIVETYPE",
                    ResourceUrl = "/v1/codes",
                    IsActive = true
                },
                new CodeKeyModel()
                {
                    Id = "2",
                    MappingKey = "DELAYREASON",
                    ResourceUrl = "/v1/codes",
                    IsActive = true
                },

                 new CodeKeyModel()
                {
                    Id = "3",
                    MappingKey = "REPAIRSITE",
                    ResourceUrl = "/v1/codes",
                    IsActive = false
                }
            };
        }

        public IList<CodeKey> GetMockCodeKeys()
        {
            return new List<CodeKey>()
            {
               new CodeKey()
                {
                    Id = "1",
                    MappingKey = "ADDITIVETYPE",
                    ResourceUrl = "/v1/codes",
                    IsActive = true
                },
                new CodeKey()
                {
                    Id = "2",
                    MappingKey = "DELAYREASON",
                    ResourceUrl = "/v1/codes",
                    IsActive = true
                },
                 new CodeKey()
                {
                    Id = "3",
                    MappingKey = "REPAIRSITE",
                    ResourceUrl = "/v1/codes",
                    IsActive = false
                }
            };
        }
    }
}

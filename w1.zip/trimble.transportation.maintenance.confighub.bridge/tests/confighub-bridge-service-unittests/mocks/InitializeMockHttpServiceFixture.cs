﻿using Moq;
using confighub.bridge.service.unittests.mocks.data;
using confighub.bridge.infrastructure.http;
using System.Net.Http;
using Moq.Protected;
using System.Threading.Tasks;
using System.Net;
using System.Threading;
using confighub.bridge.infrastructure.interfaces;

namespace confighub.bridge.service.unittests.mocks
{
    public class InitializeMockHttpServiceFixture
    {
        public Mock<IHttpClientFactory> MockIhttpClientFactory { get; }
        public Mock<IHttpClientFactory> MockExceptionIhttpClientFactory { get; }        
        public Mock<HttpMessageHandler> MockHttpMessageHandler { get; }
        public Mock<HttpMessageHandler> MockExceptionHttpMessageHandler { get; }
        public HttpClient HttpClient { get; }
        public HttpService HttpService { get; }
        public HttpClient ExceptionHttpClient { get; }
        public HttpService ExceptionHttpService { get; }
        public Mock<IHttpTransientFaultHandler> MockHttpTransientFaultHandler { get; }

        public InitializeMockHttpServiceFixture()
        {
            MockIhttpClientFactory = new Mock<IHttpClientFactory>();                        
            MockIhttpClientFactory.Setup(x => x.CreateClient(HttpServiceMockData.BaseURL)).Returns(new HttpClient());
            MockHttpMessageHandler = new Mock<HttpMessageHandler>();
            MockHttpTransientFaultHandler = new Mock<IHttpTransientFaultHandler>();
            MockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(HttpServiceMockData.HttpMessageHandleType, ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage { StatusCode = HttpStatusCode.OK });
            HttpClient = new HttpClient(MockHttpMessageHandler.Object);
            HttpService = new HttpService(MockIhttpClientFactory.Object, MockHttpTransientFaultHandler.Object);

            MockExceptionIhttpClientFactory = new Mock<IHttpClientFactory>();
            MockExceptionIhttpClientFactory.Setup(x => x.CreateClient(HttpServiceMockData.BaseURL)).Returns(new HttpClient());
            MockExceptionHttpMessageHandler = new Mock<HttpMessageHandler>();
            MockExceptionHttpMessageHandler.Protected()
               .Setup<Task<HttpResponseMessage>>(HttpServiceMockData.HttpMessageHandleType, ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
               .Throws(new TaskCanceledException());
            ExceptionHttpClient = new HttpClient(MockExceptionHttpMessageHandler.Object);
            ExceptionHttpService = new HttpService(MockExceptionIhttpClientFactory.Object, MockHttpTransientFaultHandler.Object);
        }
    }
}


﻿using confighub.bridge.service.core.services;
using confighub.bridge.service.unittests.mocks;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace confighub.bridge.service.unittests.core
{
    public class QueuedHostedServiceTest : IClassFixture<InitializeMockQueuedHostedServiceFixture>
    {
        private readonly InitializeMockQueuedHostedServiceFixture _initializeMockQueuedHostedServiceFixture;
        private QueuedHostedService _queuedHostedService;

        public QueuedHostedServiceTest(InitializeMockQueuedHostedServiceFixture initializeMockQueuedHostedServiceFixture)
        {
            _initializeMockQueuedHostedServiceFixture = initializeMockQueuedHostedServiceFixture;
        }


        [Fact]
        public async Task QueuedHostedService_ExecuteAsync_Fails_LogsErrorWithException()
        {
            var cancellationSource = new CancellationTokenSource();

            // Arrange
            _initializeMockQueuedHostedServiceFixture.MockBackgroundTaskQueue.Setup(x => x.GetQueueCount()).Returns(() => {
                cancellationSource.Cancel();
                _queuedHostedService.StopAsync(cancellationSource.Token).GetAwaiter();
                return 1;
            });
            _initializeMockQueuedHostedServiceFixture.MockBackgroundTaskQueue.Setup(x => x.DequeueBackgroundWorkItemAsync(It.IsAny<CancellationToken>())).Throws(new TaskCanceledException());

            //Act
            //Act
            _queuedHostedService = new QueuedHostedService(
                _initializeMockQueuedHostedServiceFixture.MockLoggerQueuedHostedService.Object,
                _initializeMockQueuedHostedServiceFixture.MockBackgroundTaskQueue.Object
                );

            await _queuedHostedService.StartAsync(cancellationSource.Token);

            //Assert
            _initializeMockQueuedHostedServiceFixture.MockLoggerQueuedHostedService.Verify(l => l.Log(LogLevel.Error, 0,
            It.Is<It.IsAnyType>((v, t) => true), It.IsAny<Exception>(),
            It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), Times.Once);

            await _queuedHostedService.StopAsync(cancellationSource.Token);

        }

    }
}

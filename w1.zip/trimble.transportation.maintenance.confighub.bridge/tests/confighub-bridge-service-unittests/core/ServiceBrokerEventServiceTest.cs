﻿using confighub.bridge.service.core.services;
using confighub.bridge.infrastructure.services;
using confighub.bridge.service.unittests.mocks;
using System;
using System.Threading.Tasks;
using Xunit;

namespace confighub.bridge.service.unittests.core
{
    public class ServiceBrokerEventServiceTest : IClassFixture<InitializeMockServiceBrokerEventsFixture>
    {
        //readonly InitializeMockServiceBrokerEventsFixture _initializeMockServiceBrokerEventsFixture;
        //private ServiceBrokerEventService _serviceBrokerEventService;
        //public ServiceBrokerEventServiceTest(InitializeMockServiceBrokerEventsFixture initializeMockServiceBrokerEventsFixture)
        //{
        //    _initializeMockServiceBrokerEventsFixture = initializeMockServiceBrokerEventsFixture;
        //}
        //[Fact]
        //public async Task ServiceBrokerEventService_GetAsync_Return_Success()
        //{
        //    //Arrange  
        //    _initializeMockServiceBrokerEventsFixture.MockRepositoryWrapper.Setup(x => x.GetAllAsync()).Returns(_initializeMockServiceBrokerEventsFixture.MockServiceBrokerEventMockData.Object.GetMockServiceBrokerEvent());
        //    _serviceBrokerEventService = new ServiceBrokerEventService(_initializeMockServiceBrokerEventsFixture.MockRepositoryWrapper.Object);
        //    //Act
        //    var serviceBroker = _serviceBrokerEventService.GetAllAsync();
        //    //Assert
        //    Assert.True(serviceBroker.Result.Count == _initializeMockServiceBrokerEventsFixture.MockServiceBrokerEventMockData.Object.GetMockServiceBrokerEvent().Result.Count);
        //}

        //[Fact]
        //public async Task ServiceBrokerEventService_GetAsync_Fails_LogsErrorWithException()
        //{
        //    try
        //    {
        //        //Arrange  
        //        _initializeMockServiceBrokerEventsFixture.MockServiceBrokerEventService.Setup(x => x.GetAllAsync())
        //        .Throws(new TaskCanceledException());
        //        //Act
        //        var serviceBroker = _initializeMockServiceBrokerEventsFixture.MockServiceBrokerEventService.Object.GetAllAsync();
        //    }
        //    catch (Exception e)
        //    {
        //        //Assert
        //        Assert.True(e.GetType() == typeof(TaskCanceledException));
        //    }

        //}

    }
}

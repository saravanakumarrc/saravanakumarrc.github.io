﻿using confighub.bridge.infrastructure.http;
using confighub.bridge.infrastructure.services;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using confighub.bridge.service.core.services;
using confighub.bridge.service.unittests.mocks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Serilog.Core;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace confighub.bridge.service.unittests.core
{
    public class InboundServiceTest : IClassFixture<InitializeMockInboundServiceFixture>
    {
        private readonly InitializeMockInboundServiceFixture _initializeMockInboundServiceFixture;
        private InboundService _inboundService;

        public InboundServiceTest(InitializeMockInboundServiceFixture initializeMockInboundServiceFixture)
        {
            _initializeMockInboundServiceFixture = initializeMockInboundServiceFixture;
}
[Fact]
        public async Task InboundService_StartAsync_Return_Success()
        {
            // Arrange   
            _initializeMockInboundServiceFixture.MockTaskQueue.CallBase = true;

            var mockUnitOfService = new Mock<UnitOfService>(_initializeMockInboundServiceFixture.MockIUnitOfServiceLogger.Object,
                            _initializeMockInboundServiceFixture.MockMessage.Object,
                            _initializeMockInboundServiceFixture.MockCodeKeyService.Object,
                            _initializeMockInboundServiceFixture.MockTokenService.Object,
                            _initializeMockInboundServiceFixture.MockCodeKeyValueService.Object,
                            _initializeMockInboundServiceFixture.MockCodeKeyLogService.Object);


            _initializeMockInboundServiceFixture.MockConsumerClientWrapper.Setup(x => x.SubscribeAsync(It.IsAny<Func<object, CancellationToken, Task>>(), It.IsAny<CancellationToken>())).
                Callback(async () =>
                {
                    await _inboundService.OnMessageReceived(
                    _initializeMockInboundServiceFixture.MockData.Object.EventMessageData(),
                    CancellationToken.None);
                });

            _initializeMockInboundServiceFixture.MockTaskQueue.Setup(x => x.DequeueBackgroundWorkItemAsync(It.IsAny<CancellationToken>())).Returns(ValueTask.FromResult<Func<CancellationToken, ValueTask<object>>>(mockUnitOfService.Object.DoWorkAsync));


            //Act
            _inboundService = new InboundService(
                _initializeMockInboundServiceFixture.MockLogger.Object,
                _initializeMockInboundServiceFixture.MockInboundProcessor.Object,
                _initializeMockInboundServiceFixture.MockConsumerClientWrapper.Object
                );

            // Assert
            Assert.True(_inboundService.StartAsync(default) == Task.CompletedTask);

            var workItem = await _initializeMockInboundServiceFixture.MockTaskQueue.Object.DequeueBackgroundWorkItemAsync(CancellationToken.None);
            Assert.NotNull(workItem);
        }

        [Fact]
        public async Task InboundService_StartAsync_Fails_LogsErrorWithException()
        {
            //Arrange           
            _initializeMockInboundServiceFixture.MockListenerServiceBusConnectionData.Setup(x => x.Value).Returns(
            _initializeMockInboundServiceFixture.MockData.Object.GetMockServiceBusConnectionData());

            _initializeMockInboundServiceFixture.MockConsumerClientWrapper.Setup(x => x.SubscribeAsync(It.IsAny<Func<object, CancellationToken, Task>>(), It.IsAny<CancellationToken>())).
               Throws(new TaskCanceledException());

            //Act
            _inboundService = new InboundService(
                _initializeMockInboundServiceFixture.MockLogger.Object,
                _initializeMockInboundServiceFixture.MockInboundProcessor.Object,
                _initializeMockInboundServiceFixture.MockConsumerClientWrapper.Object
                );

            await _inboundService.StartAsync(default);

            //Assert
            _initializeMockInboundServiceFixture.MockLogger.Verify(l => l.Log(LogLevel.Error, 0,
            It.Is<It.IsAnyType>((v, t) => true), It.IsAny<Exception>(),
            It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), Times.Once);
        }
    }
}

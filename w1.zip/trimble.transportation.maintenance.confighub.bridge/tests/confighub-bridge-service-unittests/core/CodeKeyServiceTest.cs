﻿using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.services;
using confighub.bridge.service.core.models;
using confighub.bridge.service.unittests.mocks;
using confighub.bridge.service.unittests.mocks.data;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace confighub.bridge.service.unittests.core
{
    public class CodeKeyServiceTest : IClassFixture<InitializeMockCodeKeyFixture>
    {
        private readonly InitializeMockCodeKeyFixture _initializeMockCodeKeyFixture;

        public CodeKeyServiceTest(InitializeMockCodeKeyFixture initializeMockCodeKeyFixture)
        {
            _initializeMockCodeKeyFixture = initializeMockCodeKeyFixture;
        }

        [Fact]
        public void CodeKeyService_GetActiveCodeKeysAsync_ShouldReturn_OnlyActiveCodeKeys()
        {
            //Arrange
            var codeKeyModel = _initializeMockCodeKeyFixture.MockData.Object.GetMockCodeKeyModels().Where(p => p.IsActive == true).ToList();
            var codeKeys = _initializeMockCodeKeyFixture.MockData.Object.GetMockCodeKeys().Where(p => p.IsActive == true).ToList();

            _initializeMockCodeKeyFixture.MockCodeKeyRepository
                .Setup(r => r.FindAll(It.IsAny<Expression<Func<CodeKey, bool>>>()))
                .ReturnsAsync(codeKeys);

            var codeKeyService = new CodeKeyService(_initializeMockCodeKeyFixture.MockCodeKeyRepository.Object, 
                _initializeMockCodeKeyFixture.MockMaintenanceDBContext.Object, 
                AutoMapperConfiguration.Configure());

            //Act
            var results = codeKeyService.GetAsync().Result;

            //Assert
            Assert.NotEmpty(results);
            Assert.Equal(codeKeyModel.Count(), codeKeys.Count());
        }
    }
}

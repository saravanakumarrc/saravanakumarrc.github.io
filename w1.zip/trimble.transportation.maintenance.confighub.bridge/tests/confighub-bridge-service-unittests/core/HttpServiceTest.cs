using Xunit;
using System.Threading.Tasks;
using Moq;
using System.Threading;
using confighub.bridge.service.unittests.mocks;
using System.Collections.Generic;
using System.Net.Http;
using Moq.Protected;
using confighub.bridge.service.unittests.mocks.data;
using System;

namespace confighub.bridge.service.unittests.core
{
    public class HttpServiceTest : IClassFixture<InitializeMockHttpServiceFixture>
    {
        readonly InitializeMockHttpServiceFixture _initializeMockHttpServiceFixture;

        public HttpServiceTest(InitializeMockHttpServiceFixture initializeMockHttpServiceFixture)
        {
            _initializeMockHttpServiceFixture = initializeMockHttpServiceFixture;
        }

        
        public async Task HttpService_GetAsync_Return_Success()
        {
            //Act
            var response = await _initializeMockHttpServiceFixture.HttpService.GetAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());

            //Assert
            Assert.NotNull(response);
            Assert.True(response.IsSuccessStatusCode);
            _initializeMockHttpServiceFixture.MockHttpMessageHandler.Protected().Verify(
               "SendAsync",
               Times.Exactly(1),
               ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Get),
               ItExpr.IsAny<CancellationToken>());
        }

        
        public async Task HttpService_GetAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Act
                var response = await _initializeMockHttpServiceFixture.ExceptionHttpService.GetAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());
            }
            catch (Exception e)
            {
                //Assert
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }

        
        public async Task HttpService_PostAsync_Return_Success()
        {
            //Act
            var response = await _initializeMockHttpServiceFixture.HttpService.PostAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), HttpServiceMockData.ContentType, It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());

            //Assert
            Assert.NotNull(response);
            Assert.True(response.IsSuccessStatusCode);
            _initializeMockHttpServiceFixture.MockHttpMessageHandler.Protected().Verify(
               "SendAsync",
               Times.Exactly(1),
               ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post),
               ItExpr.IsAny<CancellationToken>());
        }

        
        public async Task HttpService_PostAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Act
                var response = await _initializeMockHttpServiceFixture.ExceptionHttpService.PostAsync(
                    HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());
            }
            catch (Exception e)
            {
                //Assert
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }

        
        public async Task HttpService_PutAsync_Return_Success()
        {
            //Act
            var response = await _initializeMockHttpServiceFixture.HttpService.PutAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());

            //Assert
            Assert.NotNull(response);
            Assert.True(response.IsSuccessStatusCode);
            _initializeMockHttpServiceFixture.MockHttpMessageHandler.Protected().Verify(
               "SendAsync",
               Times.Exactly(1),
               ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Put),
               ItExpr.IsAny<CancellationToken>());
        }

       
        public async Task HttpService_PutAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Act
                var response = await _initializeMockHttpServiceFixture.ExceptionHttpService.PutAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());
            }
            catch (Exception e)
            {
                //Assert
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }

        
        public async Task HttpService_DeleteAsync_Return_Success()
        {
            //Act
            var response = await _initializeMockHttpServiceFixture.HttpService.DeleteAsync(
                HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());

            //Assert
            Assert.NotNull(response);
            Assert.True(response.IsSuccessStatusCode);
            _initializeMockHttpServiceFixture.MockHttpMessageHandler.Protected().Verify(
               "SendAsync",
               Times.Exactly(1),
               ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Delete),
               ItExpr.IsAny<CancellationToken>());
        }

        
        public async Task HttpService_DeleteAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Act
                var response = await _initializeMockHttpServiceFixture.ExceptionHttpService.DeleteAsync(
                    HttpServiceMockData.BaseURL, HttpServiceMockData.BaseURL, It.IsAny<string>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>());
            }
            catch (Exception e)
            {
                //Assert
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }
    }
}

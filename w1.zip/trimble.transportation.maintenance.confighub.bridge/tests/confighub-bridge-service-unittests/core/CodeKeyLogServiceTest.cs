﻿using confighub.bridge.infrastructure.interfaces;
using confighub.bridge.infrastructure.mapping;
using confighub.bridge.infrastructure.models;
using confighub.bridge.infrastructure.services;
using confighub.bridge.service.core.models;
using confighub.bridge.service.unittests.mocks;
using confighub.bridge.service.unittests.mocks.data;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace confighub.bridge.service.unittests.core
{
    public class CodeKeyLogServiceTest : IClassFixture<InitializeMockCodeKeyLogFixture>
    {
        private readonly InitializeMockCodeKeyLogFixture _initializeMockCodeKeyLogFixture;

        public CodeKeyLogServiceTest(InitializeMockCodeKeyLogFixture initializeMockCodeKeyLogFixture)
        {
            _initializeMockCodeKeyLogFixture = initializeMockCodeKeyLogFixture;
        }

        [Fact]
        public async void CodeKeyLogService_PostAsync_ShouldReturn_SuccessResponse()
        {
            //Arrange  
            _initializeMockCodeKeyLogFixture.MockHttpService.Setup(x => x.PostAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>()))
                .Returns(_initializeMockCodeKeyLogFixture.MockData.Object.GetPostData());


            _initializeMockCodeKeyLogFixture.MockTtcConfigAuthentication.Setup(ttc => ttc.Value).Returns(_initializeMockCodeKeyLogFixture.MockData.Object.MockTtcConfigAuthOption);

            var codeKeyService = new CodeKeyLogService(_initializeMockCodeKeyLogFixture.MockHttpService.Object, _initializeMockCodeKeyLogFixture.MockTtcConfigAuthentication.Object);

            //Act
            var httpResult = await codeKeyService.PostAsync(It.IsAny<string>(), _initializeMockCodeKeyLogFixture.MockData.Object.GetMockCodeKeyResultModels(), _initializeMockCodeKeyLogFixture.MockData.Object.MockMessage);

            //Assert
            Assert.NotNull(httpResult);
            Assert.Equal(HttpStatusCode.Created.ToString(), httpResult.StatusCode.ToString());
        }
    }
}

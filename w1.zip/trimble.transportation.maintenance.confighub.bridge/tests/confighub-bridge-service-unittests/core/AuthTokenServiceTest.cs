using System;
using Xunit;
using System.Threading.Tasks;
using Moq;
using System.Threading;
using confighub.bridge.service.unittests.mocks;
using System.Collections.Generic;
using confighub.bridge.infrastructure.http;

namespace confighub.bridge.service.unittests.core
{
    public class AuthTokenServiceTest : IClassFixture<InitializeMockAuthTokenServiceFixture>
    {
        readonly InitializeMockAuthTokenServiceFixture _initializeMockAuthTokenServiceFixture;
        private AuthTokenService _authTokenService;

        public AuthTokenServiceTest(InitializeMockAuthTokenServiceFixture initializeMockAuthTokenServiceFixture)
        {
            _initializeMockAuthTokenServiceFixture = initializeMockAuthTokenServiceFixture;
        }

        
        public async Task AuthTokenService_GetBearerTokenAsync_Return_Success()
        {
            //Arrange  
            _initializeMockAuthTokenServiceFixture.MockIHttpService.Setup(x => x.PostAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>(), It.IsAny<CancellationToken>(), It.IsAny<Dictionary<string, string>>()))
                .Returns(_initializeMockAuthTokenServiceFixture.MockAuthTokenServiceMockData.Object.GetPostData());

            _authTokenService = new AuthTokenService(
                _initializeMockAuthTokenServiceFixture.MockIHttpService.Object,
                _initializeMockAuthTokenServiceFixture.MockAuthTokenServiceLogger.Object);

            //Act
            var bearerToken = await _authTokenService.GetBearerTokenAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>());

            var mockBearerToken = _initializeMockAuthTokenServiceFixture.MockAuthTokenServiceMockData.Object.getTtcConfigAuthentication();

            //Assert
            Assert.True(bearerToken.ToString() == mockBearerToken.AccessToken);
        }

        [Fact]
        public async Task AuthTokenService_GetBearerTokenAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Arrange        
                _initializeMockAuthTokenServiceFixture.MockAuthTokenService.Setup(x => x.GetBearerTokenAsync(
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).
                    Throws(new TaskCanceledException());

                //Act
                await _initializeMockAuthTokenServiceFixture.MockAuthTokenService.Object.GetBearerTokenAsync(
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>());
            }
            catch (Exception e)
            {
                //Assert
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }
    }
}

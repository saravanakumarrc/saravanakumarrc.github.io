﻿using integration.service.kafka.test.mocks.data;
using integration.services.kafka.shared.consumer;
using Moq;
using Confluent.Kafka;
using confighub.bridge.infrastructure.models;
using Microsoft.Extensions.Logging;

namespace integration.service.kafka.test.mocks
{
    public class InitializeMockConsumerFixture
    {
        public Mock<ConsumerConnectionOptions> MockItopicConnectionOptions { get; }
        public Mock<ConsumerMockData> MockConsumerMockData { get; }
        public Mock<Consumer> MockConsumerWrapper { get; }
        public Mock<IConsumer<Ignore, string>> MockConsumer { get; }
        public Mock<ConsumerBuilder<Ignore, string>> MockConsumerBuilder { get; }
        public Mock<ILogger<Consumer>> MockLogger { get; }


        public InitializeMockConsumerFixture()
        {
            MockItopicConnectionOptions = new Mock<ConsumerConnectionOptions>();
            MockConsumerMockData = new Mock<ConsumerMockData>();
            MockLogger = new Mock<ILogger<Consumer>>();
            MockConsumerWrapper = new Mock<Consumer>(MockItopicConnectionOptions.Object, MockLogger.Object);
            MockConsumer = new Mock<IConsumer<Ignore, string>>();
            MockConsumerBuilder = new Mock<ConsumerBuilder<Ignore, string>>(new ConsumerConfig());
        }
    }
}

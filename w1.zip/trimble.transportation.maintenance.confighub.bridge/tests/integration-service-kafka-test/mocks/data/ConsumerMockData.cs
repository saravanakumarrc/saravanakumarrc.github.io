﻿using CloudNative.CloudEvents;
using CloudNative.CloudEvents.Extensions;
using CloudNative.CloudEvents.Kafka;
using CloudNative.CloudEvents.NewtonsoftJson;
using Confluent.Kafka;
using confighub.bridge.infrastructure.models;
using integration.services.kafka.shared.converters;
namespace integration.service.kafka.test.mocks.data
{
    public class ConsumerMockData
    {
        public ConsumerMockData() { }

        public ConsumeResult<Ignore, string> ReturnMessage()
        {
            return new ConsumeResult<Ignore, string>
            {
                Message = new Message<Ignore, string> { Value = "Test data" },
                Topic = "Test"
            };
        }
    }
}

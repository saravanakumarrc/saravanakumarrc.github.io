﻿using System;
using System.Net.Mime;
using System.Threading.Tasks;
using CloudNative.CloudEvents;
using Confluent.Kafka;
using integration.services.kafka.shared.converters;
using Newtonsoft.Json;
using CloudNative.CloudEvents.Kafka;
using CloudNative.CloudEvents.NewtonsoftJson;
using confighub.bridge.service.core.models;

namespace integration.service.kafka.test.mocks.data
{
    public class ProducerMockData
    {
        public ProducerMockData() { }       
        public Message GetMessage()
        {
            return new Message
            {
                EventId = Guid.NewGuid().ToString(),
                EventSource = new Uri("https://github.com/cloudevents/spec/pull"),
                EventType = "Test",
                EventSubject = "Test"
            };
        }       
    }
}

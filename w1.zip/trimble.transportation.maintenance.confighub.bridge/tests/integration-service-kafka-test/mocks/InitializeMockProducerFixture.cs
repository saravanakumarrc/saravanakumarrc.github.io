﻿using integration.service.kafka.test.mocks.data;
using integration.services.kafka.shared.interfaces;
using integration.services.kafka.shared.producer;
using Moq;
using Confluent.Kafka;

namespace integration.service.kafka.test.mocks
{
    public class InitializeMockProducerFixture
    {
        public Mock<ITopicConnectionOptions> MockItopicConnectionOptions { get; }
        public Mock<ProducerMockData> MockProducerMockData { get; }
        public Mock<Producer> MockProducerWrapper { get; }

        public Mock<IProducer<string, string>> MockProducer { get; }

        public Mock<ProducerBuilder<string, string>> MockProducerBuilder { get; }


        public InitializeMockProducerFixture()
        {
            MockItopicConnectionOptions = new Mock<ITopicConnectionOptions>();
            MockProducerMockData = new Mock<ProducerMockData>();
            MockProducer = new Mock<IProducer<string, string>>();
            MockProducerBuilder = new Mock<ProducerBuilder<string, string>>(new ProducerConfig());
            MockProducerWrapper = new Mock<Producer>(MockItopicConnectionOptions.Object);
        }
    }
}

﻿using Confluent.Kafka;
using integration.service.kafka.test.mocks;
using integration.services.kafka.shared.producer;
using Moq;
using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using confighub.bridge.service.core.models;
using Xunit;

namespace integration.service.kafka.test.core
{
    public class ProducerTest : IClassFixture<InitializeMockProducerFixture>
    {
        readonly InitializeMockProducerFixture _initializeConsumerFixture;
        public Producer _producer;
        public ProducerTest(InitializeMockProducerFixture initializeMockProducerFixture)
        {
            _initializeConsumerFixture = initializeMockProducerFixture;
        }

        [Fact]
        public async void kafka_PublishAsync_Return_Success()
        {
            _initializeConsumerFixture.MockProducer.Setup(x =>
                    x.ProduceAsync(It.IsAny<string>(), It.IsAny<Message<string, string>>(), It.IsAny<CancellationToken>()))
                .Returns(
                  Task.FromResult(new DeliveryResult<string, string>
                  {
                      Status = PersistenceStatus.Persisted,
                      Topic = "Test"
                  }));

            var producer = new Producer(_initializeConsumerFixture.MockItopicConnectionOptions.Object,
                _initializeConsumerFixture.MockProducerBuilder.Object,
                _initializeConsumerFixture.MockProducer.Object);

            var deliveryReport = await producer.PublishAsync(It.IsAny<string>(), _initializeConsumerFixture.MockProducerMockData.Object.GetMessage());

            Assert.True(deliveryReport.Status == PersistenceStatus.Persisted);
        }

        [Fact]
        public async Task kafka_PublishAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Arrange           
                _initializeConsumerFixture.MockProducerWrapper.Setup(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()))
               .Throws(new TaskCanceledException());

                //Act
                await _initializeConsumerFixture.MockProducerWrapper.Object.PublishAsync(It.IsAny<string>(), It.IsAny<object>());
            }
            catch (Exception e)
            {
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }
    }
}

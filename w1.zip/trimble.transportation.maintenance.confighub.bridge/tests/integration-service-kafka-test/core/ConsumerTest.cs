﻿using Xunit;
using integration.service.kafka.test.mocks;
using System.Threading.Tasks;
using integration.services.kafka.shared.consumer;
using Moq;
using System;
using System.Threading;
using CloudNative.CloudEvents;
using Confluent.Kafka;

namespace integration.service.kafka.test.core
{
    public class ConsumerTest : IClassFixture<InitializeMockConsumerFixture>
    {
        readonly InitializeMockConsumerFixture _initializeConsumerFixture;
        public ConsumerTest(InitializeMockConsumerFixture initializeConsumerFixture)
        {
            _initializeConsumerFixture = initializeConsumerFixture;
        }

        [Fact]
        public async void kafka_SubscribeAsync_Return_Success()
        {
            var cancelToken = new CancellationTokenSource();

            _initializeConsumerFixture.MockConsumer.Setup(x =>
                  x.Subscribe(It.IsAny<string>())).Callback(() => { });

            _initializeConsumerFixture.MockConsumer.Setup(x =>
                  x.Consume(It.IsAny<CancellationToken>())).Returns(() =>
                  {
                      cancelToken.Cancel();
                      return _initializeConsumerFixture.MockConsumerMockData.Object.ReturnMessage();
                  });

            var consumer = new Consumer(_initializeConsumerFixture.MockItopicConnectionOptions.Object,
                _initializeConsumerFixture.MockConsumerBuilder.Object,
                _initializeConsumerFixture.MockConsumer.Object);

            await consumer.SubscribeAsync(It.IsAny<string>(), It.IsAny<Func<object, CancellationToken, Task>>(), cancelToken.Token);
            var receivedMsg = _initializeConsumerFixture.MockConsumer.Object.Consume(cancelToken.Token);

            Assert.True(receivedMsg.Message.Value == "Test data");
        }

        [Fact]
        public async Task kafka_SubscribeAsync_Fails_LogsErrorWithException()
        {
            try
            {
                //Arrange           
                _initializeConsumerFixture.MockConsumerWrapper.Setup(x => x.SubscribeAsync(
                    It.IsAny<string>(), It.IsAny<Func<object, CancellationToken, Task>>(), It.IsAny<CancellationToken>()))
                   .Throws(new TaskCanceledException());

                //Act
                await _initializeConsumerFixture.MockConsumerWrapper.Object.SubscribeAsync(
                   It.IsAny<string>(), It.IsAny<Func<object, CancellationToken, Task>>(), It.IsAny<CancellationToken>());
            }
            catch (Exception e)
            {
                Assert.True(e.GetType() == typeof(TaskCanceledException));
            }
        }
    }
}

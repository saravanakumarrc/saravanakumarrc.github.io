﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.exceptions
{
    public class DataValueNotFoundException : Exception
    {
        public string MappingKey { get; }

        public DataValueNotFoundException()
        {
            
        }

        public DataValueNotFoundException(string message)
            : base(message)
        {
        }

        public DataValueNotFoundException(string message, Exception inner)
            : base(message, inner)
        {
        }

        public DataValueNotFoundException(string message, string mappingKey)
            : this(message)
        {
            MappingKey = mappingKey;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.exceptions
{
    public class DataValueRecordCountMismatchException : Exception
    {
        public string MappingKey { get; }

        public DataValueRecordCountMismatchException()
        {
            
        }

        public DataValueRecordCountMismatchException(string message)
            : base(message)
        {
        }

        public DataValueRecordCountMismatchException(string message, Exception inner)
            : base(message, inner)
        {
        }

        public DataValueRecordCountMismatchException(string message, string mappingKey)
            : this(message)
        {
            MappingKey = mappingKey;
        }
    }
}

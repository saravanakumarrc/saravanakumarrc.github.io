﻿using System;
using System.Net;

namespace confighub.bridge.core.extentions
{
    public static class HttpStatusCodeExtensions
    {
        public static int ToInt(this HttpStatusCode statusCode)
        {
            return Convert.ToInt32(statusCode);
        }
    }
}

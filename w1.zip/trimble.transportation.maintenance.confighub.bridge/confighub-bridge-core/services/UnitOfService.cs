﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using confighub.bridge.core.constants;
using confighub.bridge.service.core.enums;
using confighub.bridge.service.core.interfaces;
using confighub.bridge.service.core.models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog.Context;

namespace confighub.bridge.service.core.services
{
    public class UnitOfService : IUnitOfService
    {
        private readonly ILogger<IUnitOfService> _logger;
        private readonly IMessage _message;
        private readonly ICodeKeyService _codeKeyService;
        private readonly ITokenService _tokenService;
        private readonly ICodeKeyValueService _codeKeyValueService;
        private readonly ICodeKeyLogService _codeKeyLogService;

        public UnitOfService(ILogger<IUnitOfService> logger, 
                            IMessage message, 
                            ICodeKeyService codeKeysService, 
                            ITokenService tokenService,
                            ICodeKeyValueService codeKeyValueService,
                            ICodeKeyLogService codeKeyLogService)
        {
            _logger = logger;
            _message = message;
            _codeKeyService = codeKeysService;
            _tokenService = tokenService;
            _codeKeyValueService = codeKeyValueService;
            _codeKeyLogService = codeKeyLogService;
        }

        public virtual async ValueTask<object> DoWorkAsync(CancellationToken cancellationToken)
        {
            using (LogContext.PushProperty("CorrId", _message.EventId))
            {
                _logger.LogDebug($"From DoWorkAsync");
                var codeKeys = await _codeKeyService.GetAsync();

                if (!string.IsNullOrEmpty(_message.AccountName))
                {
                    string bearerToken = await _tokenService.GetTokenAsync(_message.AccountName);
                    _logger.LogDebug($"confighub bridge -New bearer token  : {bearerToken}");

                    var codeKeyResponse = await _codeKeyValueService.ProcessCodeKeysAsync(codeKeys, bearerToken, _message);
                    
                    var logResponse = await _codeKeyLogService.PostAsync(bearerToken, codeKeyResponse, _message);
                    _logger.LogDebug($"confighub bridge sync completed!! : {logResponse}");
                }
            }

            return _message;
        }
    }
}

﻿using confighub.bridge.service.core.interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.services
{
    public class InboundService : IHostedService
    {
        private readonly ILogger<InboundService> _logger;
        private readonly IInboundProcessor  _inboundProcessor;
        private readonly IConsumerClientWrapper _messagingClientWrapper;

        public InboundService(ILogger<InboundService> logger, IInboundProcessor inboundProcessor, 
            IConsumerClientWrapper messagingClientWrapper)
        {
            _logger = logger;
            _inboundProcessor = inboundProcessor;
            _messagingClientWrapper = messagingClientWrapper;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogInformation($"ConfigHub Bridge Service - StartAsync");
                await _messagingClientWrapper.SubscribeAsync(OnMessageReceived, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError($"StartAsync-{ex.Message}");
            }
        }

        public virtual async Task OnMessageReceived(object message, CancellationToken ct)
        {
            try
            {
                await _inboundProcessor.ProcessReceivedMessage(message, ct);
            }
            catch (Exception e)
            {
                _logger.LogError($"{e.Message}");
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogDebug($"StopAsync");
            return Task.CompletedTask;
        }
    }
}

﻿using confighub.bridge.service.core.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.services
{
    public class BackgroundTaskQueue<T> : IBackgroundTaskQueue<T>
    {
        private readonly Channel<Func<CancellationToken, ValueTask<T>>> _queue;
        public BackgroundTaskQueue(int capacity)
        {
            var options = new BoundedChannelOptions(capacity)
            {
                FullMode = BoundedChannelFullMode.Wait
            };
            _queue = Channel.CreateBounded<Func<CancellationToken, ValueTask<T>>>(options);
        }

        public virtual async ValueTask<Func<CancellationToken, ValueTask<T>>> DequeueBackgroundWorkItemAsync(CancellationToken cancellationToken)
        {
            var workItem = await _queue.Reader.ReadAsync(cancellationToken);
            return workItem;
        }



        public virtual async ValueTask EnqueueBackgroundWorkItemAsync(Func<CancellationToken, ValueTask<T>> workItem)
        {
            if (workItem == null)
            {
                throw new ArgumentNullException(nameof(workItem));
            }

            await _queue.Writer.WriteAsync(workItem);

        }

        public virtual int GetQueueCount()
        {
            if (_queue != null && _queue.Reader != null)
                return _queue.Reader.Count;
            return 0;
        }


    }
}


﻿using confighub.bridge.service.core.interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.services
{
    public class QueuedHostedService : BackgroundService
    {
        private readonly ILogger<QueuedHostedService> _logger;
        private readonly IBackgroundTaskQueue<object> _taskQueue;
        public QueuedHostedService(ILogger<QueuedHostedService> logger, IBackgroundTaskQueue<object> taskQueue)
        {
            _logger = logger;
            _taskQueue = taskQueue;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogDebug("Started Queue.");
            await BackgroundProcessing(stoppingToken);
        }

        private async Task BackgroundProcessing(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    if (_taskQueue.GetQueueCount() > 0)
                    {
                        var workItem = await _taskQueue.DequeueBackgroundWorkItemAsync(stoppingToken);

                        if (workItem != null)
                        {
                            _logger.LogDebug($"Started DoWork");

                            // Run workItem(DoWorkAsync from IJob class) asynchronously.
                            // If we wait for this operation to over then background service will run sequentially.
                            // Hence await keyword is not added.
                            _ = Task.Run(async () =>
                            {
                                await workItem(CancellationToken.None);
                            }, CancellationToken.None)
                                .ContinueWith(_ =>
                                {
                                    if (_.Exception?.InnerException is { } inner)
                                    {
                                        _logger.LogError(inner, "An error occurred while executing back ground do work" + inner.Message);
                                    }
                                },
                                TaskContinuationOptions.OnlyOnFaulted);

                        }
                    }
                }
                catch (Exception e)
                {
                    _logger.LogError(e, "An error occurred while executing back ground do work" + e.Message);
                }
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogDebug("Stopping Queue");
            await base.StopAsync(stoppingToken);
        }


    }
}

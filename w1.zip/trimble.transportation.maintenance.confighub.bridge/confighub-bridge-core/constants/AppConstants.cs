﻿namespace confighub.bridge.core.constants
{
    /// <summary>
    /// Stored the application constants
    /// </summary>
    public class AppConstants
    {
        public const string TrimbleIdBasicPath = "api/v1/integrationconfiguration/search/";
        public const string TrimbleIdSearchParam = "{0}/TRIMBLEID/BASIC";
        public const string AccountName = "AccountName";
        public const string ClientKey = "CLIENT_KEY";
        public const string ClientSecret = "CLIENT_SECRET";
        public const string HttpContentTypeJson = "application/json";
    }
}

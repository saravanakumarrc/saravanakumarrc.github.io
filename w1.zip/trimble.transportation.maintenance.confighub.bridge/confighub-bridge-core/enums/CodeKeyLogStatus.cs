﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.enums
{
    public enum CodeKeyLogStatus
    {
        Success,
        PartialFailure,
        Failure
    }
}

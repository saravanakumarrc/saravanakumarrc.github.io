﻿using System;

namespace confighub.bridge.service.core.interfaces
{
    /// <summary>
    /// Defines a Message to be receive from the MessagingClient
    /// </summary>
    public interface IMessage
    {
        string EventId { get; set; }
        string EventType { get; set; }
        string EventSubject { get; set; }
        Uri EventSource { get; set; }
        string AccountName { get; set; }
        IExtendedProperties ExtendedProperties { get; set; }
    }

    public interface IExtendedProperties
    {
        string CreatedBy { get; set; }
        DateTime CreatedDate { get; set; }
        string ModifiedBy { get; set; }
        DateTime ModifiedDate { get; set; }
    }
}

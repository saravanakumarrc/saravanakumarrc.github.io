﻿using confighub.bridge.service.core.models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface ICodeKeyValueService
    {
        /// <summary>
        /// Process each code key that are configured in DB, stores code key values
        /// </summary>
        /// <param name="codeKeys">List of code keys that are to be synced</param>
        /// <param name="bearerToken">Auth token to connect to cloudHub and code key api service</param>
        /// <param name="message">Message is being processed</param>
        /// <returns>result as code key log details</returns>
        Task<IList<CodeKeyLogDetail>> ProcessCodeKeysAsync(IList<CodeKeyModel> codeKeys, string bearerToken, IMessage message);
    }
}
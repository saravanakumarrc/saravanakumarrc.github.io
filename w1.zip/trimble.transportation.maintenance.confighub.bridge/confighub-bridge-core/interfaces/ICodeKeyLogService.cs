﻿using confighub.bridge.service.core.models;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface ICodeKeyLogService
    {
        Task<HttpResponseMessage> PostAsync(string bearerToken, IList<CodeKeyLogDetail> details, IMessage message);
    }
}
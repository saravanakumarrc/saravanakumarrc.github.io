﻿using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface IAuthTokenService
    {
        ValueTask<object> GetBearerTokenAsync(string baseUrl, string relativePath, string authorization, string grantType, 
            string bodyContent, string contentType);       
    }
}

﻿using confighub.bridge.service.core.models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface ICodeKeyService
    {
        Task<IList<CodeKeyModel>> GetAsync();
    }
}
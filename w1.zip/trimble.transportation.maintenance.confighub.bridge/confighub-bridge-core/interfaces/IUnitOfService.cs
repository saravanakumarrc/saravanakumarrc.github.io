﻿using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface IUnitOfService
    {
        ValueTask<object> DoWorkAsync(CancellationToken stoppingToken);
    }
}

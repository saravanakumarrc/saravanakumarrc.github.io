﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface IInboundProcessor
    {
        Task ProcessReceivedMessage(object message, CancellationToken stoppingToken);
    }
}

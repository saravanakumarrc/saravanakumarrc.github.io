﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface IBackgroundTaskQueue<T>
    {
        ValueTask EnqueueBackgroundWorkItemAsync(Func<CancellationToken, ValueTask<T>> workItem);
        ValueTask<Func<CancellationToken, ValueTask<T>>> DequeueBackgroundWorkItemAsync(CancellationToken cancellationToken);
        int GetQueueCount();
    }
}

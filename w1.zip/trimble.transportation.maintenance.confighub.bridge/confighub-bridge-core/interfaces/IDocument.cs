﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace confighub.bridge.service.core.interfaces
{
    public interface IDocument 
    {
       [BsonId]
       public string Id { get; set; }
       public bool IsActive { get; set; }
       public DateTime CreatedDate { get; set; }
       public DateTime ModifiedDate { get; set; }
       public String CreatedBy { get; set; }
       public String ModifiedBy { get; set; }
    }
}

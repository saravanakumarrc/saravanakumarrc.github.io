﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.interfaces
{
    public interface IConsumerClientWrapper
    {
        Task SubscribeAsync(Func<object, CancellationToken, Task> messageHandler, CancellationToken stopToken);
    }
}

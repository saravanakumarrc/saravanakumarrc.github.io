﻿using confighub.bridge.service.core.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace confighub.bridge.service.core.models
{
    public class CodeKeyLogModel : IDocumentModel
    {
        public string Id { get; set; }
        public string EventId { get; set; }
        public string AccountId { get; set; }
        public string Status { get; set; }
        public IList<CodeKeyLogDetail> Details { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }

    public class CodeKeyLogDetail
    {
        public string MappingKey { get; set; }
        public int StatusCode { get; set; }
        public string Error { get; set; }
    }
}

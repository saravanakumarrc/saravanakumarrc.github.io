﻿namespace confighub.bridge.service.core.models
{
    /// <summary>
    /// Class to inject the TtcConfigAuthOption API
    /// </summary>   
    public class TtcConfigAuthOption
    {

        public string Authorization { get; set; }
        public string BaseUrl { get; set; }
        public string ApiBaseUrl { get; set; }
        public string Content { get; set; }
        public string ContentType { get; set; }
        public string GrantType { get; set; }       
        public string CodeKeyService { get; set; }

    }
}

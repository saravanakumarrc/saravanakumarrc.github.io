﻿using System;
using System.Collections.Generic;
using confighub.bridge.service.core.interfaces;

namespace confighub.bridge.service.core.models
{
    public class IntegrationConfigurationModel : IDocumentModel
    {
        public string Tenant { get; set; }       
        public string NodeName { get; set; }
        public Dictionary<string, object> TenantDetails { get; set; }
        public bool IsActive { get; set; }
        public string Id { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public String CreatedBy { get; set; }
        public String ModifiedBy { get; set; }
    }
}

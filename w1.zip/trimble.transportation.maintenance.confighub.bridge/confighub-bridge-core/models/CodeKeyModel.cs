﻿using System;
using System.Collections.Generic;
using confighub.bridge.service.core.interfaces;
using MongoDB.Bson.Serialization.Attributes;

namespace confighub.bridge.service.core.models
{
    public class CodeKeyModel : IDocumentModel
    {
        public string Id { get; set; }
        public string MappingKey { get; set; }       
        public string ResourceUrl { get; set; }
        public DataMappingModel DataMapping { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public String CreatedBy { get; set; }
        public String ModifiedBy { get; set; }
        public string SearchUrl { get; set; }
    }

    public class DataMappingModel
    {
        public string CodeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
}

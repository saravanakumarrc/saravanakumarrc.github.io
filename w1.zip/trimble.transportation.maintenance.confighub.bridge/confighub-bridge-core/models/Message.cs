﻿using confighub.bridge.service.core.interfaces;
using System;

namespace confighub.bridge.service.core.models
{
    public class Message : IMessage
    {
        public string EventId { get; set; }
        public string EventType { get; set; }
        public string EventSubject { get; set; }
        public Uri EventSource { get; set; }
        public string Data { get; set; }
        public string AccountName { get; set; }
        public IExtendedProperties ExtendedProperties { get; set; }
    }

    public class ExtendedProperties : IExtendedProperties
    {
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
